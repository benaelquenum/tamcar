"""Génère partie7.html (Scénarios financiers et trésorerie prévisionnelle) — cas A et cas B, depuis le modèle."""
import pathlib
import chiffres as C
import modele_tresorerie as M

ICI = pathlib.Path(__file__).parent
n, sg, mm, pct = C.n, C.sg, C.mm, C.pct
SC = ('prudent', 'base', 'ambitieux')
S = {(c, s): C.synthese(c, s) for c in C.CASES for s in SC}
CAPEX = C.capex_total()
TRI = M.TYPES['tri']
MOTO = M.TYPES['moto']
MENS_LOT_TRI = 5 * TRI['prix'] * 0.70 / 18
MENS_LOT_MOTO = 5 * MOTO['prix'] * 0.70 / 18
MENS_A = 2 * MENS_LOT_TRI
MENS_B = MENS_A + MENS_LOT_MOTO
FAC = C.FACS


def tri_jour(sc): return round(TRI['objectif'] * FAC[sc])
def moto_jour(sc): return round(MOTO['objectif'] * FAC[sc])


def part_proprio(cas, sc):
    v = 10 * TRI['objectif'] * FAC[sc] * 26 * 0.30
    if cas == 'B':
        v += 5 * MOTO['objectif'] * FAC[sc] * 26 * 0.30
    return v


def recup(prix, obj, sc): return prix / (obj * FAC[sc] * 26 * 0.53)


def tr(*cells, cls=''):
    return f'<tr{" class=" + chr(34) + cls + chr(34) if cls else ""}>' + ''.join(f'<td>{c}</td>' for c in cells) + '</tr>'


def mn_(v): return f"{v:.0f}"


A, B = S[('A', 'base')], S[('B', 'base')]
AP, BP = S[('A', 'prudent')], S[('B', 'prudent')]
AA, BA = S[('A', 'ambitieux')], S[('B', 'ambitieux')]
SEUIL_A, SEUIL_B = C.seuil('A'), C.seuil('B')
seuil_couv_tri = MENS_LOT_TRI / 5 / (26 * 0.53)
seuil_couv_moto = MENS_LOT_MOTO / 5 / (26 * 0.53)
fin_moto_commissions = 5 * MOTO['objectif'] * 26 * 0.20
fin_tri_commissions = 10 * TRI['objectif'] * 26 * 0.20
mi50, _, fi50 = C.moto_stress(0.5)
mi0, mo0, fi0 = C.moto_stress(0.0)
OPTA = C.options_correctives('A')
RA = C.reprise('A')
K1, K7, K13 = (C.tiers_k_min(m0) for m0 in (1, 7, 13))
K_PRUDENT = C.tiers_k_min(1, sc='prudent')
TIERS5 = C.tiers_effet(5, 1)
LOT1_PROPRE = [g for g in M.CAS['A'] if g['ville'] == 'Cotonou']
S10 = C.adapter_levee(10_000_000, LOT1_PROPRE)
S5 = C.adapter_levee(5_000_000, [])
PF0A, PF0B = C.plan_financement('A', 0), C.plan_financement('B', 0)
SAP7, SBP7 = C.synthese('A', 'prudent'), C.synthese('B', 'prudent')


def bas(t, mois=True):
    return f"{mm(t[0])}<small>mois {t[1]}</small>"
TA, TB = C.tracker_annuel('A'), C.tracker_annuel('B')

# répartition des charges d'exploitation (36 mois) : équipe / locaux / assurances / prestataires et promotions
def cats(s): return s['cats']

pages = []

# ------------------------------------------------------------------ 7.1 + 7.2
pages.append(f'''<!-- ============================================================ 07 · p.1 · 7.1 + 7.2 -->
<section class="page" data-filigrane="TamCar">
  <div class="sec-head"><span class="num">07</span><h1>Scénarios financiers et trésorerie prévisionnelle</h1></div>

  <div class="hero" style="margin-top:14px">
    <span class="pill">7.1 · Objet des projections financières</span>
    <div class="cols2" style="margin-top:6px">
      <p style="text-align:left">
        Les projections financières de TamCar chiffrent la capacité du modèle
        économique à financer l’acquisition progressive de la flotte, couvrir les charges
        d’exploitation et dégager une trésorerie suffisante pour assurer le développement de
        l’entreprise.
      </p>
      <p style="text-align:left">
        L’analyse repose sur trois scénarios d’activité — prudent, de base et ambitieux —
        construits autour du volume journalier de recettes généré par chaque véhicule, et sur deux
        cas de flotte : <span class="modif">le cas A (10 tricycles) et le cas B (cas A et 5 motos en
        test)</span>. Le scénario de base constitue l’hypothèse centrale du business plan, tandis
        que les deux autres permettent de mesurer la sensibilité du projet à un démarrage plus lent
        ou à une activité supérieure aux prévisions centrales.
      </p>
    </div>
  </div>

  <div class="callout" style="margin-top:12px">
    Ces projections reposent sur la mise en service des véhicules, le recrutement des
    chauffeurs, la disponibilité de la plateforme, la demande de transport et les conditions
    financières convenues avec <span class="modif">le fournisseur</span>.
  </div>

  <div class="h-serif" style="margin-top:20px">7.2 · Hypothèses retenues</div>
  <p class="intro">Le modèle financier repose sur les principales hypothèses suivantes :</p>

  <table class="tbl txt" style="margin-top:10px">
    <colgroup><col style="width:26%"><col style="width:74%"></colgroup>
    <thead><tr><th>Hypothèse</th><th>Valeur retenue</th></tr></thead>
    <tbody>
      {tr('Flotte initiale', '<span class="modif"><strong>Cas A</strong> : 10 tricycles neufs, livrés en deux lots de cinq (Cotonou au mois 1, Parakou au mois 7). <strong>Cas B</strong> : cas A et 5 motos neuves à Cotonou dès le mois 1.</span>')}
      {tr('Coût unitaire prévu', '<span class="modif">Tricycle : 1 500 000 FCFA. Moto : 550 000 FCFA.</span>')}
      {tr('Investissement total dans la flotte', f'<span class="modif">Cas A : {n(15_000_000)} FCFA. Cas B : {n(17_750_000)} FCFA.</span>')}
      {tr('Avance à la commande', f'<span class="modif">30 % : cas A {n(4_500_000)} FCFA (2 250 000 par lot) ; cas B {n(5_325_000)} FCFA, dont 825 000 pour les motos.</span>')}
      {tr('Solde à régler', f'<span class="modif">Cas A : {n(10_500_000)} FCFA ; cas B : {n(12_425_000)} FCFA ; 18 mensualités par lot ({n(MENS_LOT_TRI)} par lot de tricycles, {n(MENS_LOT_MOTO)} pour les motos). Mensualités maximales : cas A {n(MENS_A)} ; cas B {n(MENS_B)}.</span>')}
      {tr('Volume journalier de référence', f'9 000 FCFA par tricycle dans le scénario de base<span class="modif"> ; 4 500 FCFA par moto</span>.')}
      {tr('Horizon de projection', '36 mois.')}
      {tr('Modèle de flotte', 'Exploitation des véhicules, constitution progressive du fonds de rachat et cession aux chauffeurs selon les conditions contractuelles prévues. <span class="modif">Durée de cession : 36 mois pour le tricycle, 24 mois pour la moto.</span>')}
      {tr('Part de TamCar sur le volume', '<span class="modif">53 % la première année de chaque lot, 52 % ensuite (part propriétaire 30 %, plateforme 20 %, gestion du fonds de rachat 3 % puis 2 %) ; 20 % après la cession du véhicule.</span>')}
      {tr('Financement de départ', '<span class="modif">Levée de 15 000 000 FCFA, encaissée avant le mois 1.</span>')}
      {tr('Charges', f'<span class="modif">Investissements de démarrage de {n(CAPEX)} FCFA et charges mensuelles détaillés en partie 8. Trackers GPS certifiés ANATT (8.4), renouvellement annuel de l’autorisation de transporteur (280 000 F aux mois 13 et 25), impôt minimum et patente (8.3). Carburant, entretien et réparations : à la charge du conducteur.</span>')}
    </tbody>
  </table>

  <div class="callout rouille" style="margin-top:12px">
    L’échéancier de paiement constitue une hypothèse déterminante : il permet de répartir le
    financement de la flotte sur <span class="modif">dix-huit mois</span>, mais impose à TamCar de
    disposer d’une trésorerie suffisante pour honorer les mensualités, même lorsque les recettes
    d’exploitation sont inférieures aux prévisions.
  </div>

  <div class="pn"><b><!--PN--></b> sur <!--TOTAL--></div>
</section>
''')

# ------------------------------------------------------------------ 7.3
def row3(label, f):
    return tr(label, *[f(sc) for sc in SC])


pages.append(f'''<!-- ============================================================ 07 · p.2 · 7.3 -->
<section class="page" data-filigrane="TamCar">
  <div class="sec-head"><span class="num">07</span><h1>Scénarios financiers et trésorerie prévisionnelle <small>(suite)</small></h1></div>

  <div class="h-serif" style="margin-top:14px">7.3 · Les trois scénarios d’activité</div>
  <p class="intro">Le business plan retient trois hypothèses de recettes journalières par véhicule.</p>

  <table class="tbl" style="margin-top:10px">
    <colgroup><col style="width:34%"><col style="width:22%"><col style="width:22%"><col style="width:22%"></colgroup>
    <thead><tr><th>Indicateur</th><th>Scénario prudent</th><th class="tam">Scénario de base</th><th>Scénario ambitieux</th></tr></thead>
    <tbody>
      {row3('Recettes journalières par tricycle', lambda sc: (f'<span>{n(tri_jour(sc))} FCFA</span>'))}
      {row3('Recettes journalières par moto<small>cas B</small>', lambda sc: f'<span class="modif">{n(moto_jour(sc))} FCFA</span>')}
      {row3('Revenus mensuels de TamCar, année 1<small>cas A · tous les véhicules en service</small>', lambda sc: f'<span class="modif">{n(S[("A", sc)]["rec_mois_an1"])} FCFA</span>')}
      {row3('Revenus mensuels de TamCar, année 1<small>cas B</small>', lambda sc: f'<span class="modif">{n(S[("B", sc)]["rec_mois_an1"])} FCFA</span>')}
      {row3('Revenus cumulés de TamCar sur 36 mois<small>cas A · courses</small>', lambda sc: f'<span class="modif">{n(S[("A", sc)]["rec_ops"])} FCFA</span>')}
      {row3('Revenus cumulés de TamCar sur 36 mois<small>cas B · courses, hors fonds de rachat des motos</small>', lambda sc: f'<span class="modif">{n(S[("B", sc)]["rec_ops"])} FCFA</span>')}
      {row3('Délai de récupération brut d’un tricycle', lambda sc: f'Environ {mn_(recup(TRI["prix"], TRI["objectif"], sc))} mois')}
      {row3('Délai de récupération brut d’une moto', lambda sc: f'<span class="modif">Environ {mn_(recup(MOTO["prix"], MOTO["objectif"], sc))} mois</span>')}
    </tbody>
  </table>

  <div class="row c-3 stretch" style="margin-top:14px">
    <div class="tile violet">
      <div class="ico">{{{{ico:alert}}}}</div>
      <h4>Scénario prudent</h4>
      <p>Il correspond à une montée en charge plus lente, par exemple lorsque le déploiement dans certaines villes prend plus de temps. Il mesure la marge de sécurité du projet face à des recettes inférieures à l’objectif central.</p>
    </div>
    <div class="tile">
      <div class="ico">{{{{ico:target}}}}</div>
      <h4>Scénario de base</h4>
      <p>Il retient un volume journalier de 9 000 FCFA par tricycle. Il constitue la référence des projections financières et de l’échéancier de trésorerie présentés dans le business plan.</p>
    </div>
    <div class="tile vert">
      <div class="ico">{{{{ico:chart}}}}</div>
      <h4>Scénario ambitieux</h4>
      <p>Il suppose une activité plus soutenue, favorisée par une meilleure adoption de la plateforme, la fidélisation des chauffeurs et des passagers ainsi que le développement des abonnements et des usages récurrents.</p>
    </div>
  </div>

  <div class="callout rouille" style="margin-top:12px">
    Ces montants sont les résultats du modèle, à hypothèses données. Ils ne sont ni des
    revenus garantis ni une promesse de rendement pour les investisseurs.
  </div>

  <div class="callout ajout" style="margin-top:10px">
    <strong>Ce que comptent les « revenus de TamCar ».</strong> La part propriétaire (30 %), la part
    de plateforme (20 %) et la quote-part de gestion du fonds de rachat (3 % puis 2 % du prix).
    Le reste du fonds de rachat appartient au chauffeur et n’est pas un revenu de TamCar (6.1). Il
    n’entre dans la trésorerie qu’à la cession du véhicule, quand le chauffeur en devient propriétaire.
  </div>

  <div class="pn"><b><!--PN--></b> sur <!--TOTAL--></div>
</section>
''')

# ------------------------------------------------------------------ 7.4
def ecart_cell(v):
    if v >= 0:
        return f'<td class="moins"><strong>excédent de {n(v)}</strong></td>'
    return f'<td class="plus"><strong>complément de {n(-v)}</strong></td>'


lignes_proprio = ''
for cas, mens in (('A', MENS_A), ('B', MENS_B)):
    lignes_proprio += tr(f'Part propriétaire · cas {cas}', *[n(part_proprio(cas, sc)) for sc in SC])
    lignes_proprio += tr(f'Mensualités · cas {cas}', *[n(mens)] * 3)
    lignes_proprio += '<tr><td><strong>Écart · cas ' + cas + '</strong></td>' + ''.join(ecart_cell(part_proprio(cas, sc) - mens) for sc in SC) + '</tr>'

pages.append(f'''<!-- ============================================================ 07 · p.3 · 7.4 -->
<section class="page" data-filigrane="TamCar">
  <div class="sec-head"><span class="num">07</span><h1>Scénarios financiers et trésorerie prévisionnelle <small>(suite)</small></h1></div>

  <div class="h-serif" style="margin-top:14px">7.4 · Investissement dans la flotte et modalités de paiement</div>

  <div class="card" style="margin-top:12px">
    <div class="cols2">
      <p>
        L’acquisition des <span class="modif">10 tricycles (cas A)</span> représente un
        investissement total prévisionnel de <span class="modif">15 000 000</span> FCFA
        <span class="modif">; dans le cas B, les 5 motos ajoutent 2 750 000 FCFA</span>.
      </p>
      <p>
        Le montage financier prévoit une avance de <span class="modif">30 %</span> à la
        commande, puis le règlement du solde sur <span class="modif">dix-huit mois</span>.
        <span class="modif">Chaque lot est réglé de la même manière : avance de 2 250 000 FCFA puis
        {n(MENS_LOT_TRI)} FCFA par mois pour un lot de tricycles ; avance de 825 000 FCFA puis
        {n(MENS_LOT_MOTO)} FCFA par mois pour les motos.</span>
      </p>
      <p>
        Selon les hypothèses du scénario de base, la part économique revenant au propriétaire des
        véhicules représente environ <span class="modif">{n(part_proprio('A', 'base'))}</span> FCFA par mois
        <span class="modif">lorsque les deux lots de tricycles sont en service</span>. Elle couvre
        donc <span class="modif">la mensualité de {n(MENS_A)} FCFA, l’excédent de
        {n(part_proprio('A', 'base') - MENS_A)} FCFA restant à la plateforme.</span>
      </p>
      <p>
        Cette organisation permet de mobiliser progressivement les revenus d’exploitation pour
        financer les véhicules. Elle implique toutefois de suivre séparément les sommes revenant
        aux différents acteurs et de vérifier que les recettes effectivement encaissées
        permettent de respecter les échéances.
      </p>
    </div>
  </div>

  <div class="callout" style="margin-top:12px">
    Le montage repose sur les conditions convenues avec <span class="modif">le fournisseur</span> :
    modalités de paiement, prix et calendrier de livraison.
  </div>

  <div class="h-serif ajout" style="margin-top:18px">La part propriétaire couvre-t-elle les mensualités ?</div>
  <p class="intro ajout-in">Tous les véhicules en service : part propriétaire (30 % du volume) comparée aux mensualités maximales.</p>
  <table class="tbl ajout" style="margin-top:10px">
    <colgroup><col style="width:34%"><col style="width:22%"><col style="width:22%"><col style="width:22%"></colgroup>
    <thead><tr><th>Par mois, en FCFA</th><th>Prudent</th><th class="tam">De base</th><th>Ambitieux</th></tr></thead>
    <tbody>{lignes_proprio}</tbody>
  </table>

  <div class="row c-1-1 stretch ajout" style="margin-top:12px">
    <div class="callout vert">
      <strong>Seuils de couverture.</strong> La mensualité d’un tricycle ({n(MENS_LOT_TRI / 5)} F) est couverte
      par la part de TamCar dès {n(seuil_couv_tri)} F de courses par jour ({pct(100 * seuil_couv_tri / 9000, 0)} de
      l’objectif) ; celle d’une moto ({n(MENS_LOT_MOTO / 5)} F), dès {n(seuil_couv_moto)} F ({pct(100 * seuil_couv_moto / 4500, 0)}).
    </div>
    <div class="callout rouille">
      <strong>Seuils d’alerte.</strong> Pour garder une trésorerie positive chaque mois, le cas A demande {pct(SEUIL_A, 0)} de
      l’objectif et le cas B {pct(SEUIL_B, 0)}. Sous ce niveau deux mois de suite, un plan correctif est déclenché : réduction des
      charges, recrutement de véhicules de concessionnaires.
    </div>
  </div>

  <div class="pn"><b><!--PN--></b> sur <!--TOTAL--></div>
</section>
''')

# ------------------------------------------------------------------ 7.5
def ligne_tab(label, va, vb, fort=False):
    if fort:
        return tr(f'<strong>{label}</strong>', f'<strong>{va}</strong>', f'<strong>{vb}</strong>')
    return tr(label, va, vb)


pages.append(f'''<!-- ============================================================ 07 · p.4 · 7.5 -->
<section class="page" data-filigrane="TamCar">
  <div class="sec-head"><span class="num">07</span><h1>Scénarios financiers et trésorerie prévisionnelle <small>(suite)</small></h1></div>

  <div class="h-serif" style="margin-top:14px">7.5 · Projection de trésorerie sur 36 mois</div>
  <p class="intro">
    Dans le scénario de base, <span class="modif">le modèle de trésorerie de TamCar</span> chiffre
    les revenus générés par la flotte à <span class="modif">{n(A['rec_ops'])}</span> FCFA sur 36 mois dans le cas A
    <span class="modif">et à {n(B['rec_ops'] + B['fonds'])} FCFA dans le cas B (dont {n(B['fonds'])} FCFA de fonds de
    rachat encaissés à la cession des motos)</span>. Le tableau suivant reprend les principaux agrégats financiers.
  </p>

  <table class="tbl" style="margin-top:10px">
    <colgroup><col style="width:52%"><col style="width:24%"><col style="width:24%"></colgroup>
    <thead><tr><th>Scénario de base, sur 36 mois (FCFA)</th><th>Cas A</th><th class="tam">Cas B</th></tr></thead>
    <tbody>
      {ligne_tab('Levée de fonds (trésorerie de départ)', n(15_000_000), n(15_000_000))}
      {ligne_tab('Revenus générés par la flotte pour TamCar', n(A['rec_ops']), n(B['rec_ops']))}
      {ligne_tab('Fonds de rachat encaissés à la cession des motos', '—', n(B['fonds']))}
      {ligne_tab('Achat de la flotte (avances et mensualités)', n(A['flotte']), n(B['flotte']))}
      {ligne_tab('Investissements de démarrage hors flotte', n(CAPEX), n(CAPEX))}
      {ligne_tab('Charges d’exploitation cumulées', n(A['charges']), n(B['charges']))}
      {ligne_tab('Trésorerie à 36 mois', sg(A['fin']), sg(B['fin']), True)}
    </tbody>
  </table>

  <div class="h-serif ajout" style="margin-top:18px">Trésorerie cumulée, mois par mois</div>
  <div class="ajout" style="margin-top:8px; background:#fff; border:1px solid var(--trait); border-radius:18px; padding:10px 12px 4px">
    {{{{chart:tresorerie}}}}
  </div>

  <div class="card" style="margin-top:12px">
    <p>
      <span class="modif">Dans le scénario de base, le cas B garde une trésorerie positive tous les mois : point bas de
      {mm(B['mini'])} FCFA au mois {B['mois_mini']}, puis {mm(B['fin'])} au mois 36 ; flux stable dès le mois {B['stable']}.
      Le cas A passe sous zéro : point bas de {mm(A['mini'])} au mois {A['mois_mini']}, négatif pendant
      {A['tres_neg']} mois ({RA['txt']}). Il redevient positif de façon durable au mois {RA['premier']} ({mm(RA['t_premier'])}), puis
      {mm(RA['t30'])} au mois 30 et {mm(RA['t36'])} au mois 36, soit environ {mm(RA['moyen'], 2, False)} par mois. Le creux commence au
      mois {RA['neg'][0]}, avec l’impôt minimum, et atteint son point bas au mois {A['mois_mini']} : renouvellement des trackers du second lot ({n(RA['trk_creux'])} F), patente de Parakou
      et mensualités de la flotte s’ajoutent à l’autorisation ANATT du mois 13 ; sans trackers GPS (8.4), le point bas du cas A serait de
      {mm(C.sans_tracker('A')['mini'])}. Le plan l’assume : aucun réglage ne le comble, et des véhicules de concessionnaires
      le font disparaître (10.9).</span>
    </p>
    <p>
      Ces agrégats sont ceux du scénario de base <span class="modif">du modèle</span>. Chaque
      poste a son périmètre exact : les recettes générées par la flotte, les remboursements du
      financement, les charges d’exploitation et les sommes affectées au rachat des véhicules
      sont suivis séparément.
    </p>
    <p>
      Le modèle recalcule ces indicateurs dès que le montant du financement initial, les
      salaires, les loyers, les frais techniques ou les autres charges évoluent.
    </p>
  </div>

  <div class="pn"><b><!--PN--></b> sur <!--TOTAL--></div>
</section>
''')

# ------------------------------------------------------------------ 7.5 (fin) + 7.6
def ligne_cat(nom, sous, cle):
    va, vb = A['cats'][cle], B['cats'][cle]
    ta, tb = sum(A['cats'].values()), sum(B['cats'].values())
    return tr(f'{nom}<small>{sous}</small>', n(va), pct(100 * va / ta), n(vb), pct(100 * vb / tb))


def ligne_sc(cas, sc, nom):
    s = S[(cas, sc)]
    besoin = M.LEVEE - min(0, s['mini'])
    return tr(f'Cas {cas} · {nom}', sg(s['mini']) + f' (mois {s["mois_mini"]})', sg(s['fin']), str(s['mois_neg']),
              n(besoin) if s['mini'] < 0 else '15 000 000 (suffisante)')


pages.append(f'''<!-- ============================================================ 07 · p.5 · 7.5 (fin) + 7.6 -->
<section class="page dense" data-filigrane="TamCar">
  <div class="sec-head"><span class="num">07</span><h1>Scénarios financiers et trésorerie prévisionnelle <small>(suite)</small></h1></div>

  <div class="h-serif ajout" style="margin-top:14px">Où vont les charges d’exploitation</div>
  <p class="intro ajout-in">Scénario de base, 36 mois : {n(A['charges'])} FCFA (cas A) et {n(B['charges'])} FCFA (cas B), hors investissements de démarrage et achat de la flotte.</p>
  <table class="tbl ajout" style="margin-top:10px">
    <colgroup><col style="width:40%"><col style="width:15%"><col style="width:10%"><col style="width:15%"><col style="width:10%"></colgroup>
    <thead><tr><th>Poste</th><th>Cas A (FCFA)</th><th>Part</th><th>Cas B (FCFA)</th><th>Part</th></tr></thead>
    <tbody>
      {ligne_cat('Équipe', 'responsables à 3 %, secrétaire-comptable, développeur dès le mois 13, infrastructure, outil de développement', 'c_equipe')}
      {ligne_cat('Locaux', 'bureaux, électricité et eau', 'c_locaux')}
      {ligne_cat('Assurances', 'multirisque professionnelle ; véhicules, droit taxi et visite technique', 'c_assur')}
      {ligne_cat('Prestataires et promotions de lancement', 'comptable externe, juriste, promotions', 'c_presta')}
      {ligne_cat('Trackers GPS certifiés ANATT', 'payés à la livraison puis à chaque anniversaire', 'c_tracker')}
      {ligne_cat('Autorisation de transporteur ANATT', 'renouvellement annuel, 280 000 F (mois 13 et 25)', 'c_anatt')}
      {ligne_cat('Impôts et taxes', 'impôt minimum sur les sociétés, patente', 'c_impots')}
    </tbody>
  </table>
  <div class="callout ajout" style="margin-top:12px">
    <strong>Lecture.</strong> L’équipe représente environ la moitié des charges. Ce qui permet de rester
    excédentaire, c’est ce que le plan ne budgète pas : ni publicité payante, ni marketing de rue, ni radio,
    ni parrainage, ni community manager, ni entretien des véhicules (à la charge du conducteur).
  </div>

  <div class="h-serif" style="margin-top:22px">7.6 · Résistance du modèle au scénario prudent</div>

  <div class="card" style="margin-top:12px">
    <div class="cols2">
      <p>
        Le scénario prudent repose sur des recettes journalières de 7 000 FCFA par véhicule,
        contre 9 000 FCFA dans le scénario de base.
      </p>
      <p>
        <span class="modif">Dans cette hypothèse, le cas A atteint un point bas de trésorerie de
        {mm(AP['mini'])} FCFA au mois {AP['mois_mini']}, et le cas B de {mm(BP['mini'])} au mois {BP['mois_mini']}.
        Les motos réduisent le besoin de financement de {mm(BP['mini'] - AP['mini'], 1, False)}, mais aucun des deux cas
        ne tient à ce niveau d’activité.</span> Le projet
        reste particulièrement sensible au niveau de financement disponible au lancement et à la
        vitesse de montée en charge commerciale.
      </p>
      <p>
        Cette situation justifie une réserve de trésorerie, un suivi rapproché des encaissements
        et un déploiement progressif des dépenses non indispensables. Des seuils d’alerte (7.4)
        déclenchent une réaction rapide si le volume de courses reste inférieur aux prévisions.
      </p>
      <p>
        Le suivi financier compare chaque mois les recettes réelles aux
        objectifs, les commissions effectivement encaissées aux commissions théoriques, ainsi que
        les charges réalisées aux budgets prévisionnels.
      </p>
    </div>
  </div>

  <table class="tbl ajout" style="margin-top:12px">
    <colgroup><col style="width:22%"><col style="width:22%"><col style="width:16%"><col style="width:16%"><col style="width:24%"></colgroup>
    <thead><tr><th>Cas et scénario</th><th>Point bas de trésorerie</th><th>Trésorerie au mois 36</th><th>Mois à flux négatif</th><th>Levée qui couvre le scénario</th></tr></thead>
    <tbody>
      {ligne_sc('A', 'prudent', 'prudent')}
      {ligne_sc('A', 'base', 'de base')}
      {ligne_sc('A', 'ambitieux', 'ambitieux')}
      {ligne_sc('B', 'prudent', 'prudent')}
      {ligne_sc('B', 'base', 'de base')}
      {ligne_sc('B', 'ambitieux', 'ambitieux')}
    </tbody>
  </table>

  <div class="pn"><b><!--PN--></b> sur <!--TOTAL--></div>
</section>
''')


# ------------------------------------------------------------------ récapitulatif : pourquoi le cas B
REV_A = A['rec_ops']
REV_B = B['rec_ops'] + B['fonds']
D_REV = REV_B - REV_A
D_FIN = B['fin'] - A['fin']
D_INV = 2_750_000
RENDEMENT = D_FIN / D_INV
D_PRU = BP['mini'] - AP['mini']
RENDEMENT_TXT = f"{RENDEMENT:.1f}".replace('.', ',')

pages.append(f'''<!-- ============================================================ 07 · récapitulatif : pourquoi le cas B -->
<section class="page" data-filigrane="TamCar">
  <div class="sec-head"><span class="num">07</span><h1>Scénarios financiers et trésorerie prévisionnelle <small>(suite)</small></h1></div>

  <div class="h-serif" style="margin-top:14px">Le choix : dix tricycles et cinq motos (cas B)</div>

  <div class="hero" style="margin-top:12px; padding:18px 24px 16px">
    <span class="pill">Récapitulatif · la solution la plus rémunératrice</span>
    <h2 style="font-size:21px">Plus de revenus, <em>aucun mois de trésorerie négative.</em></h2>
    <div class="cols2" style="margin-top:6px">
      <p style="text-align:left">
        Le cas B ajoute cinq motos aux dix tricycles du cas A. Pour <strong>{n(D_INV)} FCFA</strong> d’investissement
        en plus, il rapporte <strong>{mm(D_REV, 1, False)} de revenus supplémentaires</strong> sur 36 mois et supprime les
        <strong>{A['tres_neg']} mois de trésorerie négative</strong> du cas A.
      </p>
      <p style="text-align:left">
        C’est la solution la plus rémunératrice et la plus sûre pour TamCar : chaque franc investi dans les motos
        rapporte <strong>{RENDEMENT_TXT}</strong> F de trésorerie supplémentaire à 36 mois, avec un risque limité par un bilan à trois mois.
      </p>
    </div>
  </div>

  <table class="tbl" style="margin-top:12px">
    <colgroup><col style="width:36%"><col style="width:22%"><col style="width:22%"><col style="width:20%"></colgroup>
    <thead><tr><th>Scénario de base, 36 mois</th><th>Cas A<br>10 tricycles</th><th class="tam">Cas B<br>10 tricycles + 5 motos</th><th>Écart</th></tr></thead>
    <tbody>
      {tr('Flotte achetée (FCFA)', n(15_000_000), n(17_750_000), sg(D_INV))}
      {tr('Revenus de TamCar (FCFA)<small>cas B : courses et fonds de rachat des motos</small>', n(REV_A), n(REV_B), sg(D_REV))}
      {tr('<strong>Trésorerie à 36 mois (FCFA)</strong>', '<strong>' + sg(A['fin']) + '</strong>', '<strong>' + sg(B['fin']) + '</strong>', '<strong>' + sg(D_FIN) + '</strong>')}
      {tr('Point bas de trésorerie', bas((A['mini'], A['mois_mini'])), bas((B['mini'], B['mois_mini'])), mm(B['mini'] - A['mini']))}
      {tr('Mois de trésorerie négative', A['tres_neg'], B['tres_neg'], sg(B['tres_neg'] - A['tres_neg']).replace('+ ', '+').replace('− ', '−'))}
      {tr('Seuil de trésorerie positive<small>part de l’objectif journalier</small>', pct(SEUIL_A, 0), pct(SEUIL_B, 0), '−' + str(round(SEUIL_A - SEUIL_B)) + ' points')}
      {tr('Scénario prudent · point bas', mm(AP['mini']), mm(BP['mini']), mm(D_PRU))}
    </tbody>
  </table>

  <div class="rule-label" style="margin-top:14px">Pourquoi opter pour le cas B</div>
  <div class="row c-1-1 stretch" style="margin-top:8px">
    <div class="tile vert">
      <div class="ico">{{{{ico:chart}}}}</div>
      <h4>Plus de revenus</h4>
      <p>{mm(D_REV, 1, False)} de revenus en plus sur 36 mois, dont {mm(B['fonds'], 1, False)} de fonds de rachat encaissés à la cession (mois 25), puis {n(fin_moto_commissions)} F de commissions par mois.</p>
    </div>
    <div class="tile">
      <div class="ico">{{{{ico:check}}}}</div>
      <h4>Un plan sans mois négatif</h4>
      <p>Trésorerie positive tous les mois : point bas de {mm(B['mini'])} au mois {B['mois_mini']}. Le cas A passe {A['tres_neg']} mois sous zéro (point bas de {mm(A['mini'])}).</p>
    </div>
  </div>
  <div class="row c-1-1 stretch">
    <div class="tile violet">
      <div class="ico">{{{{ico:target}}}}</div>
      <h4>Une marge de sécurité plus large</h4>
      <p>Trésorerie positive dès {pct(SEUIL_B, 0)} de l’objectif, contre {pct(SEUIL_A, 0)}. Dans le scénario prudent, les motos réduisent le besoin de financement de {mm(D_PRU, 1, False)}.</p>
    </div>
    <div class="tile or">
      <div class="ico">{{{{ico:users}}}}</div>
      <h4>Un second segment de clientèle</h4>
      <p>La clientèle du zémidjan à Cotonou (3.4.2) ; cession au chauffeur en 24 mois, contre 36 pour un tricycle.</p>
    </div>
  </div>

  <div class="row c-1-1 stretch" style="margin-top:10px">
    <div class="callout rouille">
      <strong>Le risque est borné.</strong> Si les motos ne roulent pas, le point bas atteint {mm(mi0)} (mois {mo0}) et le plan finit à {mm(fi0)} ; le bilan à trois mois le détecte (8.8).
    </div>
    <div class="callout vert">
      <strong>Décision.</strong> Le plan retient le cas B pour la levée de 15 000 000 FCFA : 10 tricycles en deux lots (Cotonou au mois 1,
      Parakou au mois 7) et 5 motos à Cotonou dès le mois 1. Si la levée est inférieure, la flotte s’adapte (7.9).
    </div>
  </div>

  <div class="pn"><b><!--PN--></b> sur <!--TOTAL--></div>
</section>
''')

# ------------------------------------------------------------------ 7.7 + 7.8
pages.append(f'''<!-- ============================================================ 07 · p.6 · 7.7 + 7.8 -->
<section class="page dense" data-filigrane="TamCar">
  <div class="sec-head"><span class="num">07</span><h1>Scénarios financiers et trésorerie prévisionnelle <small>(suite)</small></h1></div>

  <div class="h-serif" style="margin-top:14px">7.7 · Situation à l’issue des 36 mois</div>

  <div class="card" style="margin-top:12px">
    <div class="cols2">
      <p>
        À l’issue de la période prévue, le business plan prévoit que les
        <span class="modif">véhicules</span> sont intégralement financés et que les
        chauffeurs en deviennent propriétaires conformément aux contrats de cession.
        <span class="modif">Les motos sont cédées au mois 25 ; les tricycles le sont après 36 mois
        d’exploitation, soit au mois 37 pour le premier lot et au mois 43 pour le second.</span>
      </p>
      <p>
        Le modèle prévoit alors la poursuite de leur activité sur la plateforme TamCar, avec
        maintien de la commission applicable aux courses. <span class="modif">Au scénario de
        base, les 10 tricycles continuent de générer environ {n(fin_tri_commissions)} FCFA de
        commissions mensuelles pour la plateforme (20 % de {n(10 * 9000 * 26)} FCFA de courses) ; dans le cas
        B, les 5 motos ajoutent {n(fin_moto_commissions)} FCFA par mois dès leur cession.</span>
      </p>
      <p>
        Cette étape est importante pour la stratégie de développement : elle permet à TamCar
        de conserver une activité de mise en relation et de perception de commissions sans devoir
        financer de nouveau les mêmes véhicules.
      </p>
      <p>
        Le lancement d’un second cycle de flotte, à moyen terme, est décidé sur les résultats
        obtenus, la trésorerie disponible et la capacité de l’entreprise à financer cette
        expansion sans fragiliser son exploitation courante.
      </p>
    </div>
  </div>

  <div class="h-serif" style="margin-top:22px">7.8 · Conclusion financière</div>

  <div class="hero" style="margin-top:12px; padding:22px 26px">
    <span class="pill">Conclusion</span>
    <div class="cols2" style="margin-top:8px">
      <p style="text-align:left">
        Les projections du business plan présentent un modèle dans lequel l’activité de
        transport contribue au financement progressif de la flotte et au développement de la
        plateforme. Le scénario de base prévoit des revenus cumulés de
        <span class="modif">{mm(A['rec_ops'], 1, False)} FCFA (cas A) et {mm(B['rec_ops'] + B['fonds'], 1, False)}
        FCFA (cas B)</span> sur 36 mois et une trésorerie <span class="modif">à 36 mois de {mm(A['fin'], 1, False)} FCFA
        dans le cas A et de {mm(B['fin'], 1, False)} FCFA dans le cas B. Avec les trackers GPS, le cas B garde une
        trésorerie positive tous les mois ; le cas A a {A['tres_neg']} mois de trésorerie négative ({mm(A['mini'])} au point bas)
        que le plan assume. Le scénario prudent n’est couvert dans aucun des deux cas.</span>
      </p>
      <p style="text-align:left">
        La réalisation de ces objectifs repose sur le niveau réel d’activité, l’échéancier du
        <span class="modif">fournisseur</span>, le recouvrement des commissions et la maîtrise des
        charges : les scénarios sont les outils de pilotage de ces quatre points.
      </p>
      <p style="text-align:left">
        Le financement recherché de 15 000 000 FCFA couvre le besoin initial (investissements de
        démarrage et avances sur les véhicules, 7.9) ; tous les postes de charges sont intégrés
        au modèle, et les hypothèses d’acquisition et de cession des véhicules sont celles de la
        partie 6.
      </p>
    </div>
  </div>

  <div class="rule-label ajout" style="margin-top:18px">Ce que le plan suppose, et sa marge de sécurité</div>
  <div class="row c-3 stretch ajout" style="margin-top:10px">
    <div class="tile vert">
      <div class="ico">{{{{ico:check}}}}</div>
      <h4>Quatre réglages</h4>
      <p>Responsables payés à 3 % du volume ; ni publicité payante, ni marketing de rue, radio ou parrainage ; développeur rémunéré dès le mois 13 ; solde des véhicules sur 18 mois.</p>
    </div>
    <div class="tile">
      <div class="ico">{{{{ico:target}}}}</div>
      <h4>Marge de sécurité</h4>
      <p>Trésorerie positive chaque mois : il faut {pct(SEUIL_A, 0)} de l’objectif dans le cas A, {pct(SEUIL_B, 0)} dans le cas B. En dessous, elle devient négative.</p>
    </div>
    <div class="tile violet">
      <div class="ico">{{{{ico:briefcase}}}}</div>
      <h4>Test moto</h4>
      <p>Les 5 motos restent en service ; bilan à 3 mois. Si elles ne roulent pas, le point bas atteint {mm(mi0)} (mois {mo0}) et le plan finit à {mm(fi0)}. Détail en 8.8.</p>
    </div>
  </div>

  <div class="rule-label ajout" style="margin-top:10px">Absorber les creux de trésorerie</div>
  <div class="card ajout" style="margin-top:6px">
    <p>
      L’intégration de nouveaux véhicules hors flotte TamCar, ceux de concessionnaires, absorbe les trous de trésorerie. Ils ajoutent des recettes
      sans achat, assurance, mensualité ni tracker à la charge de TamCar : un tricycle lui rapporte environ 53 800 F par mois et lui en coûte environ 7 000. Dans le cas A, {C.tri_entres(K1)} au mois 1, {C.tri_entres(K7)} au mois 7 ou
      {C.tri_entres(K13)} au mois 13 suffisent à supprimer les {A['tres_neg']} mois de trésorerie négative ; avec cinq, la trésorerie du
      mois 36 passe de {mm(A['fin'], 1, False)} à {mm(TIERS5[2], 1, False)}. Même dans le scénario prudent, {C.mots_tri(K_PRUDENT)} dès le mois 1 suffisent.
      Ce levier dépend du recrutement de concessionnaires et de chauffeurs ; il n’est compté ni dans le cas A ni dans le cas B (10.9).
    </p>
  </div>

  <div class="pn"><b><!--PN--></b> sur <!--TOTAL--></div>
</section>
''')

pages.append(f'''<!-- ============================================================ 07 · p.7 · 7.9 -->
<section class="page" data-filigrane="TamCar">
  <div class="sec-head"><span class="num">07</span><h1>Scénarios financiers et trésorerie prévisionnelle <small>(suite)</small></h1></div>

  <div class="h-serif ajout" style="margin-top:14px">7.9 · Si la levée est de 10 M ou de 5 M FCFA</div>
  <p class="intro ajout-in">Le plan prévoit une seule levée, de 15 M FCFA. Si les fonds reçus sont inférieurs, les charges restent les mêmes et les achats de véhicules sont réduits (de moitié avec 10 M, supprimés avec 5 M). Des véhicules de concessionnaires les remplacent : le plus petit nombre qui évite tout mois de trésorerie négative.</p>

  <table class="tbl ajout" style="margin-top:8px">
    <colgroup><col style="width:28%"><col style="width:18%"><col style="width:18%"><col style="width:18%"><col style="width:18%"></colgroup>
    <thead><tr><th></th><th>15 M · cas A</th><th>15 M · cas B</th><th>10 M</th><th>5 M</th></tr></thead>
    <tbody>
      {tr('<strong>Flotte achetée par TamCar</strong>', '10 tricycles', '10 tricycles et 5 motos', '5 tricycles à Cotonou', 'Aucun véhicule')}
      {tr('<strong>Véhicules de concessionnaires</strong>', '—', '—', f"{S10['k']} tricycles dès le mois 1", f"{S5['k']} tricycles dès le mois 1")}
      {tr('Parakou', 'Ouverte au mois 7', 'Ouverte au mois 7', 'Non ouverte', 'Non ouverte')}
      {tr('Besoin au mois 0<small>investissements et avances</small>', mm(PF0A['emplois'], 2, False), mm(PF0B['emplois'], 2, False), mm(S10['m0'], 2, False), mm(S5['m0'], 2, False))}
      {tr('<strong>Point bas de trésorerie</strong>', bas((A['mini'], A['mois_mini'])), bas((B['mini'], B['mois_mini'])), bas((S10['base']['mini'], S10['base']['mois'])), bas((S5['base']['mini'], S5['base']['mois'])))}
      {tr('Mois de trésorerie négative', A['tres_neg'], B['tres_neg'], S10['base']['neg'], S5['base']['neg'])}
      {tr('<strong>Trésorerie au mois 36</strong>', mm(A['fin']), mm(B['fin']), mm(S10['base']['fin']), mm(S5['base']['fin']))}
      {tr('Scénario prudent<small>7 000 F par jour · point bas</small>', mm(SAP7['mini']), mm(SBP7['mini']), mm(S10['prudent']['mini']), mm(S5['prudent']['mini']))}
      {tr('Moitié des concessionnaires seulement<small>point bas</small>', '—', '—', mm(S10['moitie']['mini']), mm(S5['moitie']['mini']))}
      {tr('Plan inchangé, sans adaptation<small>cas A · point bas</small>', mm(A['mini']), '—', mm(S10['brut']['mini']), mm(S5['brut']['mini']))}
    </tbody>
  </table>

  <div class="row c-1-1 stretch" style="margin-top:12px">
    <div class="callout vert ajout">
      <strong>Avec 10 M FCFA.</strong> TamCar achète un seul lot de cinq tricycles à Cotonou et ouvre avec {S10['k']} tricycles de concessionnaires. Parakou n’ouvre
      pas : le second lot et le bureau ne se financent jamais sans mois négatif. Le cas A inchangé manquerait de {mm(abs(S10['brut']['mini']), 1, False)}.
    </div>
    <div class="callout rouille ajout">
      <strong>Avec 5 M FCFA.</strong> Les investissements de démarrage ({mm(S5['m0'], 2, False)}) absorbent presque tout : aucun véhicule n’est acheté. TamCar démarre comme
      plateforme, avec {S5['k']} tricycles de concessionnaires dès le mois 1. Le cas A inchangé manquerait de {mm(abs(S5['brut']['mini']), 1, False)}.
    </div>
  </div>
  <div class="callout ajout" style="margin-top:10px">
    <strong>Ce que ces deux scénarios supposent.</strong> Les concessionnaires sont recrutés avant le lancement et leurs véhicules atteignent 9 000 F par jour, avec un
    tracker à leur charge. Avec la moitié d’entre eux, le point bas tombe à {mm(S10['moitie']['mini'])} (10 M) et {mm(S5['moitie']['mini'])} (5 M). Dans le scénario prudent,
    aucun des deux ne tient. Plus la levée baisse, plus le plan dépend du recrutement de concessionnaires et moins il a de marge.
  </div>
  

  <div class="pn"><b><!--PN--></b> sur <!--TOTAL--></div>
</section>
''')

(ICI / 'partie7.html').write_text('\n'.join(pages), encoding='utf-8')
print('partie7.html :', len(pages), 'pages')
