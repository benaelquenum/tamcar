"""Génère partie10.html (Feuille de route et calendrier de déploiement).
Le texte est celui du fondateur ; les jalons en mois et les chiffres ajoutés viennent du modèle de trésorerie."""
import pathlib
import chiffres as C
import modele_tresorerie as M

ICI = pathlib.Path(__file__).parent
n, sg, mm, pct = C.n, C.sg, C.mm, C.pct

SA, SB = C.synthese('A'), C.synthese('B')
RA = C.reprise('A')
SEUIL_A, SEUIL_B = C.seuil('A'), C.seuil('B')
PF0 = {cas: C.plan_financement(cas, 0) for cas in 'AB'}
CAPEX_M0 = sum(M.CAPEX_M0.values())
LOT1 = next(g for g in M.CAS['A'] if g['ville'] == 'Cotonou')
LOT2 = next(g for g in M.CAS['A'] if g['ville'] == 'Parakou')
MOTOS = next(g for g in M.CAS['B'] if g['type'] == 'moto')
M_LOT2 = LOT2['debut']
M_CESS_MOTO = MOTOS['debut'] + C.CESSION_MOTO
M_CESS_TRI1 = LOT1['debut'] + M.TYPES['tri']['cession']
M_CESS_TRI2 = LOT2['debut'] + M.TYPES['tri']['cession']
M_FIN_MENS1 = LOT1['debut'] + 17
M_FIN_MENS2 = LOT2['debut'] + 17
M_BILAN_PARAKOU = M_LOT2 + 6
AV_LOT = LOT1['n'] * M.TYPES['tri']['prix'] * 0.30
TRK_M13 = LOT1['n'] * M.TRACKER_ANATT['tri'][1]
TRK_M19 = LOT2['n'] * M.TRACKER_ANATT['tri'][1]
DEV = M.DEVELOPPEUR
COUV_TRI = 5 * M.TYPES['tri']['prix'] * 0.70 / 18 / 5 / (26 * 0.53)
VOL_A = round(9000 * SEUIL_A / 100, -2)
VOL_B = round(9000 * SEUIL_B / 100, -2)

VM = {t: C.vehicule_marginal(t) for t in ('tri', 'tri_t', 'moto', 'moto_t')}
VM_TRK = C.vehicule_marginal('tri_t', tracker_tiers=M.TRACKER_ANATT)
VOL_TRI = 9000 * 26
PART_T1 = M.PART_TIERS_AN1
RO_TRI = 0.03 * VOL_TRI
K1, K7, K13 = (next(k for k in range(1, 40) if C.tiers_effet(k, m0)[3] == 0) for m0 in (1, 7, 13))


def tr(*cells, cls=''):
    return f'<tr{" class=" + chr(34) + cls + chr(34) if cls else ""}>' + ''.join(f'<td>{c}</td>' for c in cells) + '</tr>'


def ratio(v):
    return f"{v:.1f}".replace('.', ',')


def cout_total(v, tiers):
    return v['charges'] + v['achat'] - (v['entree'] if tiers else 0)


def eff(k, m0):
    mi, mo, fi, neg = C.tiers_effet(k, m0)
    if neg:
        return f"{mm(mi, 2)}<small>{neg} mois négatif{'s' if neg > 1 else ''}</small>"
    return f"{mm(mi, 2)}<small>aucun mois négatif</small>"


MOIS_FR = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre']
LANCEMENT = (2027, 1)                      # mois 1 du modèle : janvier 2027 (décision du fondateur)


def Date(m):
    d = date(m)
    return d[0].upper() + d[1:]


def date(m):
    """Mois du modèle -> 'janvier 2027' (mois 0 = décembre 2026)."""
    a, mo = divmod(LANCEMENT[0] * 12 + (LANCEMENT[1] - 1) + (m - 1), 12)
    return f"{MOIS_FR[mo]} {a}"


pages = []

# =====================================================================================================
# p.1 — 10.1 et 10.2
pages.append(f'''<!-- ============================================================ 10 · p.1 · 10.1 + 10.2 -->
<section class="page" data-filigrane="TamCar">
  <div class="sec-head"><span class="num">10</span><h1>Feuille de route et calendrier de déploiement</h1></div>

  <div class="hero" style="margin-top:14px">
    <span class="pill">10.1 · Objectif de la feuille de route</span>
    <div class="cols2" style="margin-top:6px">
      <p style="text-align:left">
        La feuille de route de TamCar organise le passage de la phase de préparation à l’exploitation
        commerciale, puis à la consolidation du modèle économique et à l’extension progressive de la flotte.
        Elle repose sur une montée en puissance par étapes, afin de maîtriser les dépenses, de valider les
        hypothèses opérationnelles et d’adapter le développement de la plateforme aux résultats obtenus sur
        le terrain.
      </p>
      <p style="text-align:left">
        Le déploiement initial prévoit une flotte de <span class="modif">dix tricycles répartis entre Cotonou et Parakou, à raison de
        cinq véhicules par ville (cas A) ; dans le cas B, cinq motos s’y ajoutent à Cotonou. Porto-Novo est desservie depuis Cotonou (5.2).</span>
        Cette première phase évalue le fonctionnement du dispositif dans <span class="modif">deux pôles urbains</span>,
        la capacité de mobilisation des conducteurs et la viabilité économique de l’exploitation.
      </p>
    </div>
  </div>
  <div class="callout" style="margin-top:10px">
    Le calendrier initial du projet couvrait 2026-2029.<span class="modif"> Le lancement est fixé à {date(1)} (mois 1 du modèle) ; le calendrier est actualisé en conséquence (10.6).</span>
  </div>
  

  <div class="h-serif" style="margin-top:16px">10.2 · Phase 1 — Formalisation juridique et préparation opérationnelle</div>
  <div class="card" style="margin-top:10px">
    <p style="margin-bottom:6px"><strong>Période initialement prévue : troisième trimestre 2026.</strong><span class="modif"> Période retenue : octobre à décembre 2026, avant le lancement de {date(1)}.</span> Cette phase réunit les conditions
    juridiques, financières, matérielles et techniques nécessaires au lancement de TamCar. Les principales actions prévues sont les suivantes :</p>
    <ul class="liste" style="margin-top:0">
      <li>procéder à la constitution de la société d’exploitation sous la forme juridique retenue ;</li>
      <li>organiser l’entrée des investisseurs et formaliser les apports des associés ;</li>
      <li>encadrer juridiquement la mise à disposition ou l’apport de la plateforme numérique à la société ;</li>
      <li>finaliser le financement nécessaire au lancement et à la couverture des premiers besoins de trésorerie ;</li>
      <li>engager la commande <span class="modif">du premier lot de cinq tricycles (cas B : et des cinq motos), avec 30 % à la commande ; le second lot est commandé au mois {M_LOT2 - 1}</span>, une fois le financement sécurisé ;</li>
      <li>aménager <span class="modif">le bureau de Cotonou ; celui de Parakou suit au mois {M_LOT2 - 1}</span> ;</li>
      <li>recruter la secrétaire <span class="modif">comptable, le responsable des opérations de Cotonou (celui de Parakou à l’ouverture de la ville)</span> et les conducteurs ;</li>
      <li>préparer l’extension technique de la plateforme à Parakou ;</li>
      <li>vérifier les autorisations, obligations administratives, fiscales et réglementaires applicables<span class="modif">, dont l’autorisation de transporteur de l’ANATT (300 000 F au démarrage, renouvelée chaque année pour 280 000 F) et les trackers GPS certifiés (8.4)</span>.</li>
    </ul>
    <ul class="liste ajout" style="margin-top:8px">
      <li>boucler la levée et passer la commande du premier lot au plus tard début décembre 2026, pour une livraison en {date(1)} ;</li>
      <li>mettre en service le paiement automatique par Mobile Money (FeexPay) avant le lancement ;</li>
      <li>intégrer la commande d’un véhicule de bout en bout par WhatsApp (11.10).</li>
    </ul>
  </div>
  <div class="row c-1-1 stretch" style="margin-top:10px">
    <div class="callout vert">
      <strong>Résultat attendu :</strong> disposer d’une structure juridique opérationnelle, d’un financement sécurisé, d’une équipe
      constituée et d’une plateforme prête pour le déploiement commercial.
    </div>
    <div class="callout ajout">
      <strong>Besoin au mois 0.</strong> Investissements de démarrage de {n(CAPEX_M0)} FCFA et avance de 30 % sur les véhicules :
      {mm(PF0['A']['emplois'], 1, False)} dans le cas A, {mm(PF0['B']['emplois'], 1, False)} dans le cas B, sur une levée de 15 M.
    </div>
  </div>
  <div class="callout" style="margin-top:10px">
    La constitution de la société, l’apport de la plateforme et la commande des véhicules sont coordonnés : TamCar
    ne supporte aucun engagement financier important avant d’avoir sécurisé les ressources nécessaires.
  </div>
  

  <div class="pn"><b><!--PN--></b> sur <!--TOTAL--></div>
</section>
''')

# =====================================================================================================
# p.2 — 10.3 et 10.4
pages.append(f'''<!-- ============================================================ 10 · p.2 · 10.3 + 10.4 -->
<section class="page" data-filigrane="TamCar">
  <div class="sec-head"><span class="num">10</span><h1>Feuille de route et calendrier de déploiement <small>(suite)</small></h1></div>

  <div class="h-serif" style="margin-top:14px">10.3 · Phase 2 — Lancement commercial et déploiement de la flotte</div>
  <div class="card" style="margin-top:10px">
    <p style="margin-bottom:6px"><strong>Période initialement prévue : quatrième trimestre 2026.</strong><span class="modif"> Période retenue : {date(1)} à {date(M_LOT2 - 1)} pour le premier lot (mois {LOT1['debut']} à {M_LOT2 - 1}) ; le second lot arrive en {date(M_LOT2)}.</span> Cette phase correspond au démarrage effectif des activités de transport
    et à la mise en exploitation des <span class="modif">dix</span> tricycles. Les actions prioritaires comprennent :</p>
    <ul class="liste" style="margin-top:0">
      <li>mettre les <span class="modif">dix</span> tricycles en circulation<span class="modif"> : cinq à Cotonou dès le mois {LOT1['debut']}, cinq à Parakou au mois {M_LOT2} (cas B : et cinq motos à Cotonou)</span> ;</li>
      <li>finaliser l’intégration des conducteurs et leur formation à l’utilisation de la plateforme ;</li>
      <li>déployer les outils de suivi de l’activité des conducteurs et des courses<span class="modif">, dont les trackers GPS posés à la livraison</span> ;</li>
      <li>mettre en place le suivi opérationnel de chaque ville par le responsable local ;</li>
      <li>activer les mécanismes de suivi des commissions et de régularisation des paiements ;</li>
      <li>déployer progressivement les abonnements TamPass destinés aux trajets récurrents ;</li>
      <li>suivre les premières données d’utilisation, les recettes générées et les coûts d’exploitation ;</li>
      <li>recueillir les retours des passagers et des conducteurs afin d’identifier les ajustements nécessaires.</li>
    </ul>
    <ul class="liste ajout" style="margin-top:8px">
      <li>faire le bilan du test des motos au mois 3 (cas B), sans arrêt automatique (8.8) ;</li>
      <li>ouvrir la commande par WhatsApp : tout le processus de commande, du lieu de départ au suivi de la course, passe par la messagerie que la population connectée utilise déjà (11.10).</li>
    </ul>
    <p style="margin-top:8px">
      <span class="modif">L’automatisation des paiements sera en service avant le lancement.</span> Le déploiement de TamPass suit la disponibilité des
      fonctionnalités correspondantes.<span class="modif"> TamPass existe déjà dans l’application (4.6) ; ses conditions commerciales sont arrêtées au lancement.</span>
    </p>
  </div>
  <div class="callout vert" style="margin-top:10px">
    <strong>Résultat attendu :</strong> faire fonctionner le dispositif sur le terrain, constituer une première base d’utilisateurs et
    recueillir les données nécessaires à l’évaluation du modèle économique.
  </div>
  

  <div class="h-serif" style="margin-top:18px">10.4 · Phase 3 — Suivi des performances et ajustements</div>
  <div class="card" style="margin-top:10px">
    <p style="margin-bottom:6px"><strong>Période : 2027.</strong><span class="modif"> Période retenue : {date(M_LOT2)} à {date(M_FIN_MENS2)} (mois {M_LOT2} à {M_FIN_MENS2}).</span> Après le lancement, TamCar privilégie la consolidation de son modèle avant d’engager une
    nouvelle phase d’investissement. Le suivi portera notamment sur :</p>
    <ul class="liste deux" style="margin-top:0">
      <li>le nombre de courses réalisées par véhicule et par jour ;</li>
      <li>le chiffre d’affaires généré par ville ;</li>
      <li>le montant des commissions effectivement encaissées ;</li>
      <li>le taux d’activité et la régularité des conducteurs ;</li>
      <li>les coûts <span class="modif">d’assurance, de trackers et</span> d’immobilisation des véhicules<span class="modif"> (l’entretien est à la charge du chauffeur)</span> ;</li>
      <li>le niveau des dépenses de fonctionnement de la plateforme ;</li>
      <li>l’évolution de la trésorerie et la capacité à honorer les échéances de financement ;</li>
      <li>l’adoption des fonctionnalités numériques et des abonnements TamPass.</li>
    </ul>
    <p style="margin-top:8px">
      Une attention particulière est accordée à Parakou, où le projet prévoit une phase pilote. Le maintien du dispositif dans cette ville est
      apprécié à partir des résultats réellement observés. Si l’activité demeure insuffisante malgré les mesures correctives, certains véhicules
      sont réaffectés vers les villes présentant une demande plus soutenue.<span class="modif"> Le bilan a lieu au mois {M_BILAN_PARAKOU}, en {date(M_BILAN_PARAKOU)} (9.3).</span>
    </p>
    <p style="margin-top:8px">
      Le calendrier initial prévoit également la poursuite du remboursement des véhicules et la préparation d’un deuxième cycle d’investissement.
      Cette nouvelle phase est engagée après examen des résultats du premier cycle, de la trésorerie disponible et des engagements
      financiers restant à honorer.<span class="modif"> Le solde des tricycles se paie en 18 mensualités : fin au mois {M_FIN_MENS1} ({date(M_FIN_MENS1)}) pour le premier lot, au mois {M_FIN_MENS2} ({date(M_FIN_MENS2)}) pour le second.</span>
    </p>
  </div>
  <div class="callout vert" style="margin-top:10px">
    <strong>Résultat attendu :</strong> identifier les conditions réelles de rentabilité, corriger les insuffisances du dispositif et établir
    une base de décision pour la croissance future.
  </div>

  <div class="pn"><b><!--PN--></b> sur <!--TOTAL--></div>
</section>
''')

# =====================================================================================================
# p.3 — 10.5 et 10.6
pages.append(f'''<!-- ============================================================ 10 · p.3 · 10.5 + 10.6 -->
<section class="page" data-filigrane="TamCar">
  <div class="sec-head"><span class="num">10</span><h1>Feuille de route et calendrier de déploiement <small>(suite)</small></h1></div>

  <div class="h-serif" style="margin-top:14px">10.5 · Phase 4 — Cession progressive des véhicules et développement du modèle</div>
  <div class="card" style="margin-top:10px">
    <p style="margin-bottom:6px"><strong>Période initialement prévue : 2028-2029.</strong><span class="modif"> Période retenue : {date(M_CESS_MOTO)} à {date(M_CESS_TRI2)} (mois {M_CESS_MOTO} à {M_CESS_TRI2}).</span> Le modèle économique de TamCar prévoit une cession progressive des tricycles aux
    conducteurs selon les modalités contractuelles retenues, avec une échéance de trente-six mois<span class="modif"> (vingt-quatre mois pour les motos du cas B)</span>.</p>
    <p style="margin-bottom:6px">
      Cette évolution permet aux conducteurs concernés d’accéder progressivement à la propriété de leur outil de travail, tandis que TamCar
      poursuit son activité de plateforme et perçoit les commissions prévues sur les courses réalisées, selon les conditions applicables après la
      cession.<span class="modif"> Après la cession, TamCar garde 20 % du volume, contre 52 à 53 % pendant la détention.</span>
    </p>
    <p style="margin-bottom:6px">La mise en œuvre de cette phase comprend notamment :</p>
    <ul class="liste" style="margin-top:0">
      <li>de vérifier le paiement intégral des sommes dues au titre de chaque véhicule ;</li>
      <li>de respecter les conditions contractuelles de transfert de propriété ;</li>
      <li>de régulariser les formalités administratives correspondantes ;</li>
      <li>de mesurer l’évolution des recettes de TamCar après la fin des remboursements ;</li>
      <li>d’évaluer la capacité de la plateforme à financer son développement sur ses ressources propres ;</li>
      <li>de préparer un deuxième cycle de déploiement, portant initialement sur quinze à vingt véhicules, avec des voitures selon la demande et les moyens disponibles.</li>
    </ul>
    <ul class="liste ajout" style="margin-top:8px">
      <li>d’accueillir des véhicules de concessionnaires, qui font croître les recettes sans capital (10.9).</li>
    </ul>
    <p style="margin-top:8px">
      L’extension de la flotte reste progressive : elle suit la demande observée, la disponibilité des conducteurs, la performance
      économique des véhicules et la capacité de TamCar à financer cette croissance sans fragiliser sa trésorerie.
    </p>
  </div>
  <div class="callout vert" style="margin-top:10px">
    <strong>Résultat attendu :</strong> faire évoluer TamCar d’un modèle de lancement fondé sur une première flotte financée vers un modèle d’exploitation
    durable, qui soutient de nouveaux investissements.
  </div>
  

  <div class="h-serif" style="margin-top:18px">10.6 · Tableau récapitulatif du calendrier</div>
  <table class="tbl txt" style="margin-top:10px">
    <colgroup><col style="width:11%"><col style="width:13%"><col style="width:48%"><col style="width:28%"></colgroup>
    <thead><tr><th>Phase</th><th>Période initiale</th><th>Principales réalisations attendues</th><th class="ajout-col">Calendrier retenu</th></tr></thead>
    <tbody>
      <tr><td>Phase 1</td><td>T3 2026</td><td>Constitution, financement, préparation des bureaux, recrutement et préparation technique</td><td class="ajout-col">Octobre à décembre 2026, avant le mois 1 (mois 0 : levée, commande du premier lot)</td></tr>
      <tr><td>Phase 2</td><td>T4 2026</td><td>Lancement commercial, mise en circulation des <span class="modif">dix tricycles (cinq au lancement, cinq à Parakou au mois {M_LOT2})</span> et activation des outils opérationnels</td><td class="ajout-col">{Date(LOT1['debut'])} à {date(M_LOT2 - 1)} (mois {LOT1['debut']} à {M_LOT2 - 1}, premier lot seul)</td></tr>
      <tr><td>Phase 3</td><td>2027</td><td>Suivi des performances, évaluation du pilote de Parakou et consolidation financière</td><td class="ajout-col">{Date(M_LOT2)} à {date(M_FIN_MENS2)} (mois {M_LOT2} à {M_FIN_MENS2}), dont le bilan de Parakou en {date(M_BILAN_PARAKOU)}</td></tr>
      <tr><td>Phase 4</td><td>2028-2029</td><td>Cession progressive des véhicules, évaluation du modèle et préparation de l’expansion</td><td class="ajout-col">{Date(M_CESS_MOTO)} à {date(M_CESS_TRI2)} (mois {M_CESS_MOTO} à {M_CESS_TRI2}) : motos en {date(M_CESS_MOTO)}, tricycles en {date(M_CESS_TRI1)} et {date(M_CESS_TRI2)}</td></tr>
    </tbody>
  </table>

  <div class="pn"><b><!--PN--></b> sur <!--TOTAL--></div>
</section>
''')

# =====================================================================================================
# p.4 — jalons du modèle + 10.7
jalons = [
    ('Mois 0', 'Levée de 15 M FCFA, constitution, investissements de démarrage, commande du premier lot',
     f'{n(CAPEX_M0)} F + avance de {n(AV_LOT)} F (cas B : {n(AV_LOT + MOTOS["n"] * M.TYPES["moto"]["prix"] * 0.30)} F)'),
    (f'Mois {LOT1["debut"]}', 'Livraison du premier lot (cinq tricycles à Cotonou ; cas B : cinq motos), trackers posés, lancement', 'Part de TamCar : 53 % du volume'),
    ('Mois 3', 'Bilan du test des motos (cas B)', '50 % de l’objectif : extension ; 34 % : seuil de couverture'),
    (f'Mois {M_LOT2 - 1}', 'Commande du second lot, ouverture du bureau de Parakou', f'Avance de {n(AV_LOT)} F + bureau de 500 000 F'),
    (f'Mois {M_LOT2}', 'Livraison du second lot à Parakou', 'Activité à 50 % le mois de livraison'),
    (f'Mois {M_BILAN_PARAKOU}', 'Bilan de Parakou ; développeur ; renouvellement de l’autorisation ANATT et des trackers du premier lot', f'{n(DEV)} F par mois ; {n(M.ANATT_RENOUVELLEMENT)} F + {n(TRK_M13)} F'),
    (f'Mois {M_FIN_MENS1}', 'Dernière mensualité du premier lot', 'Flotte remboursée pour moitié'),
    (f'Mois {SA["mois_mini"]}', 'Point bas de trésorerie du cas A', f'{mm(SA["mini"])} ; trackers du second lot : {n(TRK_M19)} F'),
    (f'Mois {M_FIN_MENS2}', 'Dernière mensualité du second lot', 'Flotte entièrement remboursée'),
    (f'Mois {M_CESS_MOTO}', 'Cession des motos (cas B) ; second renouvellement ANATT', 'TamCar encaisse le fonds de rachat, puis garde 20 %'),
    (f'Mois {M_CESS_TRI1} et {M_CESS_TRI2}', 'Cession du premier, puis du second lot de tricycles', 'Fin du financement de la flotte par ses recettes'),
]

def _quand(a):
    import re
    ms = [int(x) for x in re.findall(r'\d+', a)]
    return ' et '.join(date(m) for m in ms)


jalons_d = [(a, b, c, _quand(a)) for a, b, c in jalons]
lignes_j = ''.join(tr(f'<strong>{a}</strong><small>{d}</small>', b, c) for a, b, c, d in jalons_d)

pages.append(f'''<!-- ============================================================ 10 · p.4 · jalons + 10.7 -->
<section class="page" data-filigrane="TamCar">
  <div class="sec-head"><span class="num">10</span><h1>Feuille de route et calendrier de déploiement <small>(suite)</small></h1></div>

  <div class="h-serif ajout" style="margin-top:14px">Les jalons du modèle, en mois</div>
  <p class="intro ajout-in">Le mois 1 est celui de la livraison du premier lot. Il tombe en {date(1)}.</p>
  <table class="tbl txt ajout" style="margin-top:8px">
    <colgroup><col style="width:15%"><col style="width:52%"><col style="width:33%"></colgroup>
    <thead><tr><th>Quand</th><th>Jalon</th><th>Chiffre du modèle</th></tr></thead>
    <tbody>
      {lignes_j}
    </tbody>
  </table>

  <div class="h-serif" style="margin-top:20px">10.7 · Conditions de passage d’une phase à l’autre</div>
  <div class="card" style="margin-top:10px">
    <p>
      Le calendrier est la trajectoire prévisionnelle du plan. Le passage à chaque phase est conditionné par
      l’atteinte de critères vérifiables.
    </p>
    <p style="margin-top:6px">
      Avant le lancement commercial, TamCar sécurise son financement, vérifie la conformité de son dispositif réglementaire,
      confirme la disponibilité des véhicules et teste les fonctionnalités indispensables à l’exploitation.
    </p>
    <p style="margin-top:6px">
      Avant de préparer un deuxième cycle d’investissement, la société dispose de données fiables sur le volume de courses, les
      commissions encaissées, les charges réelles, les incidents opérationnels et la trésorerie.
    </p>
    <p style="margin-top:6px">
      Enfin, avant toute cession de véhicule, les obligations contractuelles, les sommes restant dues et les formalités de transfert sont
      vérifiées individuellement.
    </p>
  </div>

  <div class="pn"><b><!--PN--></b> sur <!--TOTAL--></div>
</section>
''')

# =====================================================================================================
# p.5 — 10.8
pages.append(f'''<!-- ============================================================ 10 · p.5 · 10.8 -->
<section class="page" data-filigrane="TamCar">
  <div class="sec-head"><span class="num">10</span><h1>Feuille de route et calendrier de déploiement <small>(suite)</small></h1></div>

  <div class="h-serif" style="margin-top:14px">10.7 · Conditions de passage d’une phase à l’autre <small>(suite)</small></div>
  <div class="rule-label ajout" style="margin-top:14px">Critères chiffrés de passage · tirés du modèle</div>
  <table class="tbl txt ajout" style="margin-top:8px">
    <colgroup><col style="width:30%"><col style="width:16%"><col style="width:54%"></colgroup>
    <thead><tr><th>Décision</th><th>Quand</th><th>Critère</th></tr></thead>
    <tbody>
      {tr('Commander le second lot (Parakou)', f'Mois {M_LOT2 - 1}<small>{date(M_LOT2 - 1)}</small>', f'Chauffeurs engagés à Parakou en nombre suffisant (4.2.2) ; volume par tricycle à Cotonou d’au moins {n(VOL_A)} F par jour (cas A), {n(VOL_B)} F (cas B)')}
      {tr('Étendre le test des motos', f'Mois 3<small>{date(3)}</small>', 'Au moins 2 250 F par moto et par jour (50 % de l’objectif), puis décision au bilan (8.8)')}
      {tr('Maintenir Parakou', f'Mois {M_BILAN_PARAKOU}<small>{date(M_BILAN_PARAKOU)}</small>', f'Volume par tricycle d’au moins {n(COUV_TRI)} F par jour ; en dessous, redéploiement à examiner (9.3)')}
      {tr('Préparer un deuxième cycle', f'Après le mois {M_FIN_MENS1}<small>{date(M_FIN_MENS1)}</small>', 'Trésorerie positive, premier lot remboursé, données fiables sur trois mois de suite')}
    </tbody>
  </table>


  <div class="h-serif" style="margin-top:22px">10.8 · État d’avancement et calendrier retenu</div>
  <div class="hero" style="margin-top:12px; padding:20px 26px">
    <span class="pill">Calendrier</span>
    <div class="cols2" style="margin-top:6px">
      <p style="text-align:left">
        Le calendrier initial situait la formalisation et la préparation du projet au troisième trimestre 2026, puis le lancement au quatrième
        trimestre de la même année. Au 30 septembre 2026, l’état d’avancement de chaque action est établi ci-dessous et le lancement est
        fixé à janvier 2027.
      </p>
      <p style="text-align:left">
        Les étapes déjà réalisées sont identifiées comme telles ; les autres sont reprogrammées en fonction du financement disponible, des
        délais de constitution de la société, de la commande des véhicules et de la préparation technique. Cette actualisation donne un
        calendrier cohérent avec les moyens mobilisables par TamCar.
      </p>
    </div>
  </div>

  <div class="rule-label ajout" style="margin-top:16px">État d’avancement au 30 septembre 2026 · d’après ce que contient déjà le plan</div>
  <div class="row c-1-1 stretch" style="margin-top:8px">
    <div class="card ajout">
      <div class="eyebrow vert">{{{{ico:shield}}}} Déjà en place</div>
      <ul class="liste" style="margin-top:6px">
        <li>La plateforme : passagers (web installable, APK Android), chauffeurs, back-office (4.1).</li>
        <li>Une grille de prix sans majoration dynamique, relevée le 30 septembre 2026 (3.4).</li>
        <li>Les conditions générales et la politique de confidentialité, à jour.</li>
        <li>Un forfait de 1 500 000 FCFA avec le commissaire aux apports (2.3).</li>
        <li>Les relevés de prix ANATT (autorisation, trackers), faits en juillet 2026.</li>
        <li>La dénomination Tam Logistics, disponible.</li>
        <li>Les prix, le paiement échelonné, la garantie et le calendrier de livraison des véhicules, confirmés avec le fournisseur.</li>
      </ul>
    </div>
    <div class="card ajout">
      <div class="eyebrow rouille">{{{{ico:clipboard}}}} À faire avant le mois {LOT1['debut']}</div>
      <ul class="liste rouille" style="margin-top:6px">
        <li>Constituer la SARL Tam Logistics et formaliser l’apport de la plateforme.</li>
        <li>Sécuriser la levée de 15 M FCFA.</li>
        <li>Commander le premier lot de véhicules, au plus tard début décembre 2026.</li>
        <li>Obtenir l’autorisation de transporteur ANATT et les trackers.</li>
        <li>Mettre en service le paiement automatique par Mobile Money (FeexPay).</li>
        <li>Intégrer la commande d’un véhicule de bout en bout par WhatsApp (11.10).</li>
        <li>Aménager le bureau de Cotonou ; recruter la secrétaire-comptable et le responsable des opérations.</li>
        <li>Signer les contrats chauffeurs et concessionnaires.</li>
      </ul>
    </div>
  </div>
  

  <div class="callout ajout" style="margin-top:12px">
    <strong>Calendrier retenu : lancement en {date(1)}.</strong> Premier lot en {date(1)}, second lot en {date(M_LOT2)}, bilan de Parakou en {date(M_BILAN_PARAKOU)},
    fin des mensualités en {date(M_FIN_MENS2)}, cession des motos (cas B) en {date(M_CESS_MOTO)} et des tricycles en {date(M_CESS_TRI1)} et {date(M_CESS_TRI2)}.
  </div>

  <div class="pn"><b><!--PN--></b> sur <!--TOTAL--></div>
</section>
''')

# =====================================================================================================
# p.6 — 10.9 véhicules de concessionnaires
t = VM
ACT = [(1.0, 'À l’objectif : 9 000 F par jour'), (7 / 9, 'Niveau prudent : 7 000 F par jour'), (0.5, 'À moitié : 4 500 F par jour'), (0.0, 'Ne roule pas')]
lignes_activite = ''.join(tr(nom, n(C.vehicule_marginal('tri', f=f)['net']), n(C.vehicule_marginal('tri_t', f=f)['net'])) for f, nom in ACT)
pages.append(f'''<!-- ============================================================ 10 · p.6 · 10.9 véhicules de tiers -->
<section class="page" data-filigrane="TamCar">
  <div class="sec-head"><span class="num">10</span><h1>Feuille de route et calendrier de déploiement <small>(suite)</small></h1></div>

  <div class="h-serif ajout" style="margin-top:14px">10.9 · Croissance par les véhicules de concessionnaires</div>

  <div class="hero ajout" style="margin-top:12px; padding:18px 26px">
    <span class="pill">Réponse</span>
    <div class="cols2" style="margin-top:6px">
      <p style="text-align:left">
        Avec des véhicules qui ne lui appartiennent pas, TamCar augmente ses recettes bien plus que ses charges. Un tricycle de
        concessionnaire lui rapporte {n(VOL_TRI * PART_T1)} F par mois (23 % de {n(VOL_TRI)} F de courses) et lui coûte {n(RO_TRI)} F
        (responsable des opérations à 3 %) : {ratio(t['tri_t']['rec'] / cout_total(t['tri_t'], True))} F de recettes pour 1 F de charges, contre
        {ratio(t['tri']['rec'] / cout_total(t['tri'], False))} pour un tricycle de TamCar, achat compris.
      </p>
      <p style="text-align:left">
        La raison : l’équipe, les bureaux et la plateforme existent déjà. Le véhicule de tiers ne demande ni achat, ni assurance, ni
        mensualité. Au pire, s’il ne roule pas, il coûte 75 000 F de frais d’entrée ; un tricycle acheté qui ne roule pas engage 1,5 M.
      </p>
    </div>
  </div>

  <div class="rule-label ajout" style="margin-top:14px">Un véhicule de plus, sur 36 mois · scénario de base, en FCFA</div>
  <table class="tbl ajout" style="margin-top:8px">
    <colgroup><col style="width:28%"><col style="width:18%"><col style="width:18%"><col style="width:18%"><col style="width:18%"></colgroup>
    <thead><tr><th></th><th>Tricycle de TamCar</th><th>Tricycle de concessionnaire</th><th>Moto de TamCar</th><th>Moto de concessionnaire</th></tr></thead>
    <tbody>
      {tr('<strong>Recettes de TamCar</strong>', n(t['tri']['rec']), n(t['tri_t']['rec']), n(t['moto']['rec']), n(t['moto_t']['rec']))}
      {tr('Charges liées au véhicule<small>assurance, tracker, responsable (3 %)</small>', n(t['tri']['charges']), n(t['tri_t']['charges']) + '<small>responsable (3 %) seul</small>', n(t['moto']['charges']), n(t['moto_t']['charges']) + '<small>responsable (3 %) seul</small>')}
      {tr('Achat du véhicule', n(t['tri']['achat']), '—', n(t['moto']['achat']), '—')}
      {tr('Frais d’entrée<small>avance remboursée au mois 13</small>', '—', n(-t['tri_t']['entree']), '—', n(-t['moto_t']['entree']))}
      {tr('<strong>Résultat sur 36 mois</strong>', f"<strong>{n(t['tri']['net'])}</strong>", f"<strong>{n(t['tri_t']['net'])}</strong>", f"<strong>{n(t['moto']['net'])}</strong>", f"<strong>{n(t['moto_t']['net'])}</strong>")}
      {tr('Recettes pour 1 F de charges, achat compris', ratio(t['tri']['rec'] / cout_total(t['tri'], False)), ratio(t['tri_t']['rec'] / cout_total(t['tri_t'], True)), ratio(t['moto']['rec'] / cout_total(t['moto'], False)), ratio(t['moto_t']['rec'] / cout_total(t['moto_t'], True)))}
      {tr('Capital à engager', '450 000 d’avance<small>puis 18 mensualités</small>', '<strong>0</strong>', '165 000 d’avance<small>puis 18 mensualités</small>', '<strong>0</strong>')}
    </tbody>
  </table>
  <div class="src">Par différence avec le cas A, un véhicule de plus à Cotonou dès le mois 1, objectif atteint (9 000 F par jour pour un tricycle, 4 500 F pour une moto). Hors fonds de rachat encaissé après les 36 mois.</div>

  <div class="rule-label ajout" style="margin-top:14px">Si le véhicule roule moins que prévu · résultat sur 36 mois, en FCFA</div>
  <table class="tbl ajout" style="margin-top:8px">
    <colgroup><col style="width:40%"><col style="width:30%"><col style="width:30%"></colgroup>
    <thead><tr><th>Activité du véhicule</th><th>Tricycle de TamCar</th><th>Tricycle de concessionnaire</th></tr></thead>
    <tbody>
      {lignes_activite}
    </tbody>
  </table>
  <div class="src">Hors valeur de revente du tricycle de TamCar, qui reste sa propriété : la perte réelle est plus faible.</div>

  <div class="pn"><b><!--PN--></b> sur <!--TOTAL--></div>
</section>
''')

pages.append(f'''<!-- ============================================================ 10 · p.7 · 10.9 (suite) -->
<section class="page" data-filigrane="TamCar">
  <div class="sec-head"><span class="num">10</span><h1>Feuille de route et calendrier de déploiement <small>(suite)</small></h1></div>

  <div class="h-serif ajout" style="margin-top:14px">10.9 · Croissance par les véhicules de concessionnaires <small>(suite)</small></div>
  <div class="rule-label ajout" style="margin-top:12px">Effet sur le point bas du cas A · tricycles de concessionnaires à Cotonou</div>
  <table class="tbl ajout" style="margin-top:8px">
    <colgroup><col style="width:28%"><col style="width:24%"><col style="width:24%"><col style="width:24%"></colgroup>
    <thead><tr><th>Nombre de tricycles</th><th>Entrés au mois 1</th><th>Entrés au mois 7</th><th>Entrés au mois 13</th></tr></thead>
    <tbody>
      {tr('<strong>Aucun</strong> (cas A)', *[f"{mm(SA['mini'], 2)}<small>{SA['tres_neg']} mois négatifs</small>"] * 3)}
      {''.join(tr(f'<strong>{k}</strong>', eff(k, 1), eff(k, 7), eff(k, 13)) for k in (1, 2, 3, 5, 10))}
    </tbody>
  </table>

  <div class="row c-1-1 stretch" style="margin-top:12px">
    <div class="callout vert ajout">
      <strong>Ce que cela règle.</strong> {C.tri_entres(K1).capitalize()} au mois 1, {C.tri_entres(K7)} au mois 7 ou {C.tri_entres(K13)} au mois 13 suffisent à
      supprimer le creux du cas A. Avec cinq, TamCar finit à {mm(C.tiers_effet(5, 1)[2], 1, False)} au mois 36 contre {mm(SA['fin'], 1, False)}.
    </div>
    <div class="callout rouille ajout">
      <strong>Ce que cela suppose.</strong> Des concessionnaires et des chauffeurs à recruter (Parakou a montré la difficulté) ; aucun renfort
      d’équipe ; le tracker GPS certifié à la charge du concessionnaire, pour chaque véhicule qu’il met à disposition.
    </div>
  </div>
  

  <div class="pn"><b><!--PN--></b> sur <!--TOTAL--></div>
</section>
''')

(ICI / 'partie10.html').write_text('\n'.join(pages), encoding='utf-8')
print(f'partie10.html : {len(pages)} pages')
