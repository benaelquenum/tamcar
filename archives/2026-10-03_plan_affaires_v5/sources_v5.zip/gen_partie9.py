"""Génère partie9.html (Analyse des risques et mesures d'atténuation).
Le texte est celui du fondateur ; les chiffres ajoutés viennent du modèle de trésorerie (chiffres.py)."""
import pathlib
import chiffres as C
import modele_tresorerie as M

ICI = pathlib.Path(__file__).parent
n, sg, mm, pct = C.n, C.sg, C.mm, C.pct

SA, SB = C.synthese('A'), C.synthese('B')
SAP, SBP = C.synthese('A', 'prudent'), C.synthese('B', 'prudent')
RA = C.reprise('A')
SEUIL_A, SEUIL_B = C.seuil('A'), C.seuil('B')
VOL_A = round(9000 * SEUIL_A / 100, -2)
VOL_B = round(9000 * SEUIL_B / 100, -2)
MENS_LOT_TRI = 5 * M.TYPES['tri']['prix'] * 0.70 / 18
MENS_LOT_MOTO = 5 * M.TYPES['moto']['prix'] * 0.70 / 18
COUV_TRI = MENS_LOT_TRI / 5 / (26 * 0.53)
COUV_MOTO = MENS_LOT_MOTO / 5 / (26 * 0.53)
MOTO_VIDE = C.moto_stress(0.0)
P50 = {cas: C.parakou(cas, 0.5) for cas in 'AB'}
P50R = {cas: C.parakou(cas, 0.5, True) for cas in 'AB'}
P0R = {cas: C.parakou(cas, 0.0, True) for cas in 'AB'}
VEH_A = C.vehicules('A')[2]
ANATT_RENOUV = 2 * 280_000
SANS_RENOUV = min(l['tresorerie'] for l in M.simuler_cas('A', 1.0, None, anatt=None, impots=False))


def k_mini(m0):
    """Nombre de tricycles de concessionnaires, entrés au mois m0 à Cotonou, qui suppriment tout mois négatif du cas A."""
    return next(k for k in range(1, 40) if C.tiers_effet(k, m0)[3] == 0)


K1, K7, K13 = k_mini(1), k_mini(7), k_mini(13)


def tr(*cells, cls=''):
    return f'<tr{" class=" + chr(34) + cls + chr(34) if cls else ""}>' + ''.join(f'<td>{c}</td>' for c in cells) + '</tr>'


def bas(t):
    """'−5,2 M' + mois en petit"""
    return f"{mm(t[0])}<small> (mois {t[1]})</small>"


SUITE = '<small>(suite)</small>'
pages = []

# =====================================================================================================
# p.1 — 9.1 et 9.2 (les six risques du texte)
pages.append(f'''<!-- ============================================================ 09 · p.1 · 9.1 + 9.2 -->
<section class="page" data-filigrane="TamCar">
  <div class="sec-head"><span class="num">09</span><h1>Analyse des risques et mesures d’atténuation</h1></div>

  <div class="hero" style="margin-top:14px">
    <span class="pill">9.1 · Une approche préventive des risques</span>
    <div class="cols2" style="margin-top:6px">
      <p style="text-align:left">
        Le développement de TamCar repose sur plusieurs facteurs interdépendants : l’adoption de la
        plateforme par les clients, la disponibilité des chauffeurs, la rentabilité de la flotte, la
        fiabilité des outils numériques et le respect des obligations applicables au transport.
      </p>
      <p style="text-align:left">
        Le projet prévoit donc des mesures destinées à anticiper les difficultés, à limiter leurs
        conséquences et à préserver la continuité de l’activité. Une étude juridique des risques
        a été réalisée, une cartographie des risques établie (ci-dessous), et une stratégie de réduction,
        voire d’élimination, de chaque risque élaborée : ces mesures sont traduites en procédures
        opérationnelles, en clauses contractuelles et en indicateurs de suivi.
      </p>
    </div>
  </div>

  <div class="h-serif" style="margin-top:16px">9.2 · Principaux risques identifiés</div>

  <table class="tbl txt" style="margin-top:10px">
    <colgroup><col style="width:22%"><col style="width:28%"><col style="width:50%"></colgroup>
    <thead><tr><th>Risque</th><th>Conséquence possible</th><th>Mesures prévues</th></tr></thead>
    <tbody>
      {tr('Adoption insuffisante à Parakou',
          'Volume de courses inférieur aux prévisions et immobilisation de véhicules',
          'Lancement pilote avec cinq unités, responsable local rémunéré à la performance et possibilité de redéployer les véhicules vers le Sud après six mois si les résultats sont insuffisants. <span class="modif">L’ouverture est conditionnée à un nombre suffisant de chauffeurs engagés (4.2.2).</span>')}
      {tr('Activité insuffisante d’un chauffeur',
          'Baisse des recettes et difficulté à respecter l’échéancier de la flotte',
          'Suivi du volume de courses, seuil contractuel d’activité et procédure d’avertissement puis de réaffectation du véhicule.')}
      {tr('Difficultés de recouvrement des commissions en espèces',
          'Retards ou pertes de recettes pour la plateforme',
          'Débit automatique de la commission sur le compte du chauffeur pour chaque course payée en espèces et blocage de la mise en ligne en cas de solde négatif <span class="modif">au-delà d’une tolérance de 5 000 F (6.3)</span>, jusqu’à régularisation.')}
      {tr('Casse, vol ou détournement d’un véhicule',
          'Perte financière, interruption du service et difficulté de remboursement',
          'Assurance, inspections périodiques, <span class="modif">traceur GPS certifié ANATT, obligatoire et payé par TamCar jusqu’à la cession (8.4),</span> et encadrement contractuel de la propriété du véhicule jusqu’à la cession complète. <span class="modif">Les réparations et l’entretien sont à la charge du chauffeur (6.4).</span>')}
      {tr('Pression concurrentielle sur les prix',
          'Baisse des marges et difficulté à fidéliser les chauffeurs et les clients',
          'Différenciation par la tarification annoncée à l’avance<span class="modif">, sans hausse dynamique (3.4)</span>, la qualité de service, la fidélisation des chauffeurs et le mécanisme de cession progressive des véhicules.')}
      {tr('Risques réglementaires et fiscaux',
          'Retard de lancement, dépenses supplémentaires ou sanctions',
          'Vérification des autorisations requises <span class="modif">(autorisation de transporteur et trackers certifiés de l’ANATT)</span>, conformité des actes de la société, validation juridique des conditions générales d’utilisation et vérification du régime fiscal applicable.')}
    </tbody>
  </table>

  <div class="callout" style="margin-top:12px">
    Ces réponses reprennent les risques et mesures retenus <span class="modif">dès la conception du projet</span>.
    Leur efficacité est mesurée en exploitation par les indicateurs du 9.8.
  </div>
  

  <div class="pn"><b><!--PN--></b> sur <!--TOTAL--></div>
</section>
''')

# =====================================================================================================
# p.2 — risques ajoutés + coût des risques dans le modèle
lignes_sens = [
    tr('<strong>Scénario de base</strong><small>référence</small>', bas((SA['mini'], SA['mois_mini'])), bas((SB['mini'], SB['mois_mini'])), mm(SA['fin']), mm(SB['fin'])),
    tr('<strong>Tricycles à 7 000 F par jour</strong><small>au lieu de 9 000 F (scénario prudent)</small>', bas((SAP['mini'], SAP['mois_mini'])), bas((SBP['mini'], SBP['mois_mini'])), mm(SAP['fin']), mm(SBP['fin'])),
    tr('<strong>Parakou à 50 % de l’objectif</strong><small>sans redéploiement</small>', bas(P50['A']), bas(P50['B']), mm(P50['A'][2]), mm(P50['B'][2])),
    tr('<strong>Parakou à 50 % pendant 6 mois</strong><small>puis redéploiement des 5 tricycles au Sud, à l’objectif</small>', bas(P50R['A']), bas(P50R['B']), mm(P50R['A'][2]), mm(P50R['B'][2])),
    tr('<strong>Parakou sans aucune course pendant 6 mois</strong><small>puis redéploiement au Sud, à l’objectif</small>', bas(P0R['A']), bas(P0R['B']), mm(P0R['A'][2]), mm(P0R['B'][2])),
    tr('<strong>Les cinq motos ne font aucune course</strong><small>cas B seulement</small>', '—', bas(MOTO_VIDE), '—', mm(MOTO_VIDE[2])),
]

pages.append(f'''<!-- ============================================================ 09 · p.2 · risques ajoutés + sensibilité -->
<section class="page" data-filigrane="TamCar">
  <div class="sec-head"><span class="num">09</span><h1>Analyse des risques et mesures d’atténuation <small>(suite)</small></h1></div>

  <div class="h-serif ajout" style="margin-top:14px">9.2 (suite) · Quatre risques complémentaires</div>
  <p class="intro ajout-in">Quatre autres risques complètent le tableau : le financement, le test des motos, la fiabilité des outils numériques et la dépendance à une équipe restreinte. Les deux premiers découlent des parties 7 et 8.</p>

  <table class="tbl txt" style="margin-top:8px">
    <colgroup><col style="width:22%"><col style="width:28%"><col style="width:50%"></colgroup>
    <thead><tr><th>Risque</th><th>Conséquence possible</th><th>Mesures prévues</th></tr></thead>
    <tbody>
      {tr('Financement et trésorerie',
          f'Point bas de {mm(SA["mini"])} au mois {SA["mois_mini"]} dans le cas A ; scénario prudent non couvert par la levée de 15 M, dans les deux cas (8.8). Avec 10 M ou 5 M, la flotte propre est réduite et des véhicules de concessionnaires deviennent nécessaires (7.9).',
          f'Suivi mensuel de la trésorerie ; seuils de pilotage à {pct(SEUIL_A, 0)} (cas A) et {pct(SEUIL_B, 0)} (cas B) de l’objectif ; plan correctif (réduction des charges, véhicules de concessionnaires). Prix, calendrier et paiement échelonné des véhicules confirmés avec le fournisseur (8.6). Véhicules de concessionnaires : {C.tri_entres(K1)} au mois 1, {C.tri_entres(K7)} au mois 7 ou {C.tri_entres(K13)} au mois 13 suffisent à supprimer le creux du cas A (10.9).',
          cls='ajout-ligne')}
      {tr('Test des motos insuffisant (cas B)',
          f'Volume trop faible pour couvrir la mensualité (seuil : {n(COUV_MOTO)} F par jour) ; point bas de {mm(MOTO_VIDE[0])} si les cinq motos ne roulent pas.',
          'Bilan à 3 mois, sans arrêt automatique : extension à partir de 50 % de l’objectif, poursuite sans extension entre 34 et 50 %, plan correctif sous 34 % (8.8).',
          cls='ajout-ligne')}
      {tr('Panne de la plateforme ou du paiement mobile',
          'Courses non commandées ou non payées, litiges de paiement, perte de confiance des clients et des chauffeurs.',
          'Suivi de la disponibilité et des délais de résolution des incidents techniques (5.7) ; paiement en espèces maintenu en secours ; développeur rémunéré à partir du mois 13 (5.4).',
          cls='ajout-ligne')}
      {tr('Dépendance à une équipe restreinte',
          'Retard de développement ou d’exploitation si le fondateur ou le développeur devient indisponible.',
          'Secrétaire-comptable dès le lancement, responsable des opérations dans chaque ville (5.2) ; procédures et code documentés avant l’arrivée du développeur.',
          cls='ajout-ligne')}
    </tbody>
  </table>

  <div class="h-serif ajout" style="margin-top:18px">Ce que coûtent les principaux risques dans le modèle</div>
  <p class="intro">Trésorerie avec 15 M FCFA de levée, scénario de base sauf mention. Un point bas négatif se lit comme un besoin de financement en plus de la levée.</p>
  <table class="tbl ajout" style="margin-top:6px">
    <colgroup><col style="width:38%"><col style="width:17%"><col style="width:17%"><col style="width:14%"><col style="width:14%"></colgroup>
    <thead><tr><th>Événement</th><th>Point bas · cas A</th><th>Point bas · cas B</th><th>Mois 36 · A</th><th>Mois 36 · B</th></tr></thead>
    <tbody>
      {''.join(lignes_sens)}
    </tbody>
  </table>
  <div class="src">Le redéploiement suppose que le Sud absorbe les cinq tricycles à l’objectif de 9 000 F par jour ; les coûts de transfert ne sont pas chiffrés.</div>

  <div class="row c-1-1 stretch" style="margin-top:12px">
    <div class="callout ajout">
      <strong>Le risque le plus lourd.</strong> L’activité des véhicules pèse davantage que les coûts : à 7 000 F par jour,
      le point bas passe à {mm(SAP['mini'])} (cas A) ; avec Parakou à 50 % et sans redéploiement, il atteint {mm(P50['A'][0])}.
    </div>
    <div class="callout vert ajout">
      <strong>Ce qui protège le plus.</strong> Le redéploiement après six mois ramène ce point bas à {mm(P50R['A'][0])} (cas A)
      et {mm(P50R['B'][0])} (cas B) : la décision du mois 13 vaut environ {mm(P50R['A'][0] - P50['A'][0], 1, False)}.
    </div>
  </div>

  <div class="pn"><b><!--PN--></b> sur <!--TOTAL--></div>
</section>
''')

# =====================================================================================================
# p.3 — 9.3 et 9.4
pages.append(f'''<!-- ============================================================ 09 · p.3 · 9.3 + 9.4 -->
<section class="page" data-filigrane="TamCar">
  <div class="sec-head"><span class="num">09</span><h1>Analyse des risques et mesures d’atténuation <small>(suite)</small></h1></div>

  <div class="h-serif" style="margin-top:14px">9.3 · Maîtriser le risque commercial et territorial</div>
  <div class="card" style="margin-top:10px">
    <div class="cols2">
      <p>
        Le déploiement à Parakou est un lancement distinct de celui du Sud, en phase pilote. Le plan prévoit cinq tricycles pour cette ville et une évaluation après six mois.
      </p>
      <p>
        Cette approche limite l’exposition initiale. Des critères définis à l’avance déclenchent le
        maintien, l’ajustement ou l’arrêt du pilote ; ils portent sur le nombre de courses réalisées, le
        taux d’utilisation des véhicules, les recettes générées et la capacité à recruter puis fidéliser les
        chauffeurs.
      </p>
      <p>
        En cas de résultats insuffisants, le redéploiement des véhicules vers les zones où la demande est
        plus forte est prévu comme solution de repli. Cette possibilité est examinée au regard des
        contrats conclus, des coûts logistiques et des conditions concrètes de réaffectation.
      </p>
    </div>
  </div>

  <div class="rule-label ajout" style="margin-top:14px">Critères du bilan de Parakou au mois 13</div>
  <table class="tbl txt ajout" style="margin-top:8px">
    <colgroup><col style="width:28%"><col style="width:24%"><col style="width:24%"><col style="width:24%"></colgroup>
    <thead><tr><th>Critère</th><th>Maintien</th><th>Ajustement</th><th>Redéploiement à examiner</th></tr></thead>
    <tbody>
      {tr('Volume par tricycle et par jour<small>moyenne mensuelle glissante, 26 jours</small>',
          '9 000 F ou plus<small>objectif atteint</small>',
          f'De {n(COUV_TRI)} à 9 000 F<small>la part de TamCar couvre la mensualité</small>',
          f'Moins de {n(COUV_TRI)} F<small>mensualité non couverte</small>')}
      <tr><td>Courses, taux d’utilisation, chauffeurs recrutés et fidélisés</td><td colspan="3">Seuils arrêtés au plan opérationnel, d’après les premiers résultats du Sud</td></tr>
    </tbody>
  </table>
  

  <div class="h-serif" style="margin-top:20px">9.4 · Prévenir les défauts d’activité des chauffeurs</div>
  <div class="card" style="margin-top:10px">
    <div class="cols2">
      <p>
        Le modèle de flotte prévoit un plancher contractuel de 9 000 FCFA de volume de courses par jour,
        calculé sur une moyenne mensuelle glissante et sur une base de 26 jours travaillés par mois.
      </p>
      <p>
        Ce seuil est l’objectif contractuel et opérationnel du business plan ; la demande varie selon les
        jours, les zones et les périodes.
      </p>
      <p>
        Le suivi distingue donc les difficultés temporaires, les problèmes d’affectation
        géographique et les insuffisances persistantes d’activité. Avant toute réaffectation, TamCar
        applique une procédure clairement définie, documentée et conforme aux contrats conclus avec les
        chauffeurs.
      </p>
      <p>
        Les abonnements TamPass contribuent à la récurrence des trajets ; leur effet tient au nombre
        d’abonnés, à la fréquence des déplacements et aux conditions commerciales mises en place.
      </p>
    </div>
  </div>

  <div class="callout ajout" style="margin-top:12px">
    <strong>Le plancher est aussi l’objectif du scénario de base.</strong> Un tricycle exactement au plancher laisse le cas A
    à {mm(SA['mini'])} au point bas : pour éviter tout mois négatif, il faudrait {n(VOL_A)} F par jour dans le cas A et
    {n(VOL_B)} F dans le cas B (8.8). Pour une moto, le plancher est de 4 500 F (5.7).
  </div>

  <div class="pn"><b><!--PN--></b> sur <!--TOTAL--></div>
</section>
''')

# =====================================================================================================
# p.4 — 9.5, 9.6
pages.append(f'''<!-- ============================================================ 09 · p.4 · 9.5 + 9.6 -->
<section class="page" data-filigrane="TamCar">
  <div class="sec-head"><span class="num">09</span><h1>Analyse des risques et mesures d’atténuation <small>(suite)</small></h1></div>

  <div class="h-serif" style="margin-top:14px">9.5 · Sécuriser les recettes et les véhicules</div>
  <div class="card" style="margin-top:10px">
    <div class="cols2">
      <p>
        Le recouvrement des commissions est essentiel pour éviter que les courses payées en espèces ne
        créent un décalage entre les montants dus à la plateforme et les sommes effectivement perçues.
      </p>
      <p>
        Le dispositif <span class="modif">décrit en 6.3</span> prévoit le débit automatique de la commission et la suspension de la
        mise en ligne lorsque le compte du chauffeur présente un solde négatif non régularisé<span class="modif"> (au-delà de la tolérance
        de 5 000 F)</span>. Le bon fonctionnement de ce mécanisme est contrôlé régulièrement,
        notamment en cas de panne réseau, de paiement incomplet ou de contestation d’une course.
      </p>
      <p>
        La flotte constitue par ailleurs un actif important. Les contrats, les assurances, les inspections
        et le suivi des véhicules<span class="modif">, par trackers GPS certifiés (8.4),</span> réduisent les risques de détournement, de dommages et
        d’immobilisation prolongée. La réserve de propriété <span class="modif">prévue en 6.4</span> est formalisée dans les
        contrats et sécurisée juridiquement jusqu’à la réalisation de la cession.
      </p>
    </div>
  </div>

  <div class="row c-1-1 stretch" style="margin-top:12px">
    <div class="callout ajout">
      <strong>Une protection qui s’écrit et se publie.</strong> Une clause de réserve de propriété est convenue par
      écrit et, pour valoir contre les tiers, publiée au RCCM (Acte uniforme OHADA sur les sûretés, art. 72 et suivants).
      Elle est rédigée dans les contrats de cession.
    </div>
    <div class="callout ajout">
      <strong>Ce que TamCar possède.</strong> Jusqu’à la cession, TamCar est propriétaire de {n(VEH_A)} FCFA de véhicules
      dans le cas A et {n(C.vehicules('B')[2])} FCFA dans le cas B : c’est l’actif que ces mesures protègent.
    </div>
  </div>

  

  <div class="h-serif" style="margin-top:22px">9.6 · Faire face à la concurrence</div>
  <div class="card" style="margin-top:10px">
    <div class="cols2">
      <p>
        TamCar se différencie par un prix annoncé avant la commande, une expérience numérique
        intégrée, l’accompagnement des chauffeurs et un mécanisme de cession progressive des véhicules.
      </p>
      <p>
        Cette stratégie ne supprime pas le risque concurrentiel : une baisse de prix d’un concurrent, une
        évolution des habitudes des utilisateurs ou une offre de rémunération plus attractive pour les
        chauffeurs affecte les volumes de courses.
      </p>
      <p>
        TamCar suit donc régulièrement ses tarifs, les délais de prise en charge, les annulations,
        la satisfaction des clients, la fidélité des chauffeurs et la rentabilité par ville. Toute réponse
        concurrentielle est évaluée à partir de ses effets sur les marges et la trésorerie, plutôt
        que par une baisse de prix automatique.
      </p>
    </div>
  </div>

  <div class="row c-1-1 stretch" style="margin-top:12px">
    <div class="callout ajout">
      <strong>Le point de départ est mesuré.</strong> Sur le relevé du 30 septembre 2026, TamCar est de 11 à 25 % plus cher
      que Yango sur la voiture ordinaire et moins cher que Gozem ; sur une course courte, il est de 46 % moins cher
      qu’INAS en voiture (3.4) ; inDrive, limité à la moto, fonctionne sur un prix proposé par le client (3.4.5). Le risque tient à cet écart avec Yango, que le prix
      annoncé, sans hausse dynamique, justifie.
    </div>
    <div class="callout rouille ajout">
      <strong>Ce que coûte une baisse de prix.</strong> À nombre de courses constant, une baisse de prix réduit d’autant le volume
      facturé par véhicule : à 7 000 F par jour au lieu de 9 000 (− 22 %), le point bas passe à {mm(SAP['mini'])} dans le cas A et
      {mm(SBP['mini'])} dans le cas B.
    </div>
  </div>

  <div class="pn"><b><!--PN--></b> sur <!--TOTAL--></div>
</section>
''')

# =====================================================================================================
# p.5 — 9.7 et 9.8
pages.append(f'''<!-- ============================================================ 09 · p.5 · 9.7 + 9.8 -->
<section class="page" data-filigrane="TamCar">
  <div class="sec-head"><span class="num">09</span><h1>Analyse des risques et mesures d’atténuation <small>(suite)</small></h1></div>

  <div class="h-serif" style="margin-top:14px">9.7 · Respecter les obligations réglementaires et fiscales</div>
  <div class="card" style="margin-top:10px">
    <div class="cols2">
      <p>
        TamCar vérifie les autorisations liées à l’activité de transport,
        les obligations administratives de la société, les règles applicables aux chauffeurs et aux
        véhicules, ainsi que les obligations fiscales et sociales pertinentes.
      </p>
      <p>
        Le <span class="modif">plan prévoit notamment l’autorisation de transporteur et les trackers certifiés de l’ANATT</span>, la conformité des actes de la société au droit
        OHADA et la validation juridique des conditions générales d’utilisation. Ces éléments sont
        confirmés auprès des autorités compétentes et des conseils concernés avant le lancement.
      </p>
      <p>
        Le régime fiscal <span class="modif">retenu</span> est vérifié au regard de la
        situation effective de la société et des textes applicables à la date de son immatriculation.
        Aucune exonération ou facilité fiscale n’est comptée dans le plan avant sa confirmation.
      </p>
    </div>
  </div>

  <div class="row c-1-1 stretch" style="margin-top:12px">
    <div class="callout ajout">
      <strong>Ce que le plan chiffre.</strong> L’autorisation ANATT (300 000 F au démarrage, puis 280 000 F à chaque renouvellement annuel, aux mois 13 et 25), les trackers
      ({n(sum(C.tracker_annuel('A')))} F sur 36 mois dans le cas A, 8.4), l’impôt minimum sur les sociétés ({n(M.IS_MINIMUM)} F par an) et la patente
      ({n(M.PATENTE['Cotonou'])} F à Cotonou, {n(M.PATENTE['Parakou'])} F à Parakou), soit {n(SA['cats']['c_impots'])} F d’impôts et taxes sur 36 mois dans le cas A (8.3).
      Aucune exonération n’est comptée.
    </div>
    <div class="callout rouille ajout">
      <strong>Effet sur le plan.</strong> Le renouvellement de l’autorisation ({n(ANATT_RENOUV)} F aux mois 13 et 25) et les impôts et taxes creusent le point bas du cas A
      de {mm(SANS_RENOUV - SA['mini'], 2, False)} (de {mm(SANS_RENOUV)} à {mm(SA['mini'])}), (l’autorisation seule représente {pct(100 * ANATT_RENOUV / M.LEVEE, 1)} de la levée).
    </div>
  </div>
  

  <div class="h-serif" style="margin-top:20px">9.8 · Organiser le suivi des risques</div>
  <div class="card" style="margin-top:10px">
    <p style="margin-bottom:6px">
      La gestion des risques ne se limite pas à leur identification initiale. TamCar met en
      place un suivi régulier fondé sur des données vérifiables. Les indicateurs prioritaires comprennent :
    </p>
    <ul class="liste deux" style="margin-top:0">
      <li>le nombre de chauffeurs actifs par ville ;</li>
      <li>le nombre de courses réalisées et leur évolution ;</li>
      <li>le volume de courses par véhicule ;</li>
      <li>les annulations, incidents et réclamations ;</li>
      <li>les commissions dues, encaissées et en retard ;</li>
      <li>les véhicules immobilisés <span class="modif">et la durée d’immobilisation (les réparations sont à la charge du chauffeur)</span> ;</li>
      <li>la trésorerie disponible et les échéances à venir ;</li>
      <li>les coûts d’acquisition et de fidélisation des utilisateurs.</li>
    </ul>
    <ul class="liste deux ajout" style="margin-top:8px">
      <li>le volume par moto au bilan de 3 mois (cas B) ;</li>
      <li>l’état des trackers : véhicules localisables, renouvellements à l’échéance.</li>
    </ul>
    <p style="margin-top:8px">
      Un tableau de bord mensuel repère les écarts par rapport aux prévisions et décide
      des actions correctives. Les seuils d’alerte ci-dessous sont tirés du modèle, puis ajustés
      sur les données réelles.
    </p>
  </div>

  <div class="pn"><b><!--PN--></b> sur <!--TOTAL--></div>
</section>
''')

# =====================================================================================================
# p.6 — conclusion
pages.append(f'''<!-- ============================================================ 09 · p.6 · conclusion -->
<section class="page" data-filigrane="TamCar">
  <div class="sec-head"><span class="num">09</span><h1>Analyse des risques et mesures d’atténuation <small>(suite)</small></h1></div>

  <div class="h-serif" style="margin-top:14px">9.8 · Organiser le suivi des risques <small>(suite)</small></div>
  <div class="rule-label ajout" style="margin-top:10px">Seuils d’alerte · tirés du modèle</div>
  <table class="tbl txt ajout" style="margin-top:8px">
    <colgroup><col style="width:30%"><col style="width:32%"><col style="width:38%"></colgroup>
    <thead><tr><th>Indicateur</th><th>Seuil d’alerte</th><th>Décision</th></tr></thead>
    <tbody>
      {tr('Volume par tricycle<small>moyenne glissante, 26 jours</small>', f'Sous {n(VOL_A)} F (cas A) ou {n(VOL_B)} F (cas B)', 'Plan correctif si l’écart dure deux mois de suite (7.4)')}
      {tr('Mensualité couverte par la part de TamCar', f'Sous {n(COUV_TRI)} F par tricycle, {n(COUV_MOTO)} F par moto', 'Plan correctif, puis redéploiement à examiner (8.6)')}
      {tr('Volume par moto au mois 3', 'Sous 2 250 F (50 %) puis sous 1 552 F (34 %)', 'Pas d’extension, puis plan correctif et nouveau bilan (8.8)')}
      {tr('Dette d’un chauffeur sur courses en espèces', 'Plus de 5 000 F', 'Mise en ligne bloquée jusqu’à la recharge (6.3)')}
      {tr('Ouverture de Parakou', 'Chauffeurs engagés en nombre insuffisant', 'Ouverture différée (4.2.2)')}
    </tbody>
  </table>


  <div class="h-serif" style="margin-top:22px">Conclusion</div>

  <div class="hero" style="margin-top:12px; padding:22px 26px">
    <span class="pill">Conclusion</span>
    <div class="cols2" style="margin-top:8px">
      <p style="text-align:left">
        Les principaux risques de TamCar concernent l’adoption commerciale, la régularité de l’activité des
        chauffeurs, la protection de la flotte, le recouvrement des commissions, la concurrence et la
        conformité réglementaire. Le projet prévoit déjà plusieurs mécanismes de prévention, notamment un
        déploiement pilote à Parakou, des seuils contractuels d’activité, l’automatisation du recouvrement
        et le suivi des véhicules<span class="modif"> par trackers GPS certifiés</span>.
      </p>
      <p style="text-align:left">
        Ces mesures sont traduites en procédures concrètes, en engagements contractuels et en
        indicateurs de contrôle ; les performances présentées sont les projections du modèle.
      </p>
    </div>
  </div>

  <div class="rule-label ajout" style="margin-top:16px">Ce que l’investisseur doit retenir de cette partie</div>
  <div class="row c-3 stretch" style="margin-top:8px">
    <div class="tile ajout">
      <div class="ico">{{{{ico:chart}}}}</div>
      <h4>L’activité décide</h4>
      <p>Tout se joue sur le volume par véhicule : {pct(SEUIL_A, 0)} de l’objectif dans le cas A, {pct(SEUIL_B, 0)} dans le cas B pour ne jamais passer sous zéro.</p>
    </div>
    <div class="tile violet ajout">
      <div class="ico">{{{{ico:target}}}}</div>
      <h4>Parakou se décide au mois 13</h4>
      <p>Le redéploiement ramène le point bas de {mm(P50['A'][0])} à {mm(P50R['A'][0])} si Parakou ne fait que 50 % de l’objectif (cas A).</p>
    </div>
    <div class="tile vert ajout">
      <div class="ico">{{{{ico:shield}}}}</div>
      <h4>Le creux du cas A est assumé</h4>
      <p>{mm(SA['mini'])} au mois {SA['mois_mini']}, puis {mm(RA['t36'])} au mois 36 : le plan le montre tel quel.</p>
    </div>
  </div>

  <div class="pn"><b><!--PN--></b> sur <!--TOTAL--></div>
</section>
''')

(ICI / 'partie9.html').write_text('\n'.join(pages), encoding='utf-8')
print(f'partie9.html : {len(pages)} pages')
