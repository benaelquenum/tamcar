"""Génère partie8.html (Charges d'exploitation et plan de financement) à partir du modèle. Cas A et cas B."""
import pathlib
import chiffres as C
import modele_tresorerie as M

ICI = pathlib.Path(__file__).parent
n, sg, mm, pct = C.n, C.sg, C.mm, C.pct

SA, SB = C.synthese('A'), C.synthese('B')
SAP, SBP = C.synthese('A', 'prudent'), C.synthese('B', 'prudent')
SAA, SBA = C.synthese('A', 'ambitieux'), C.synthese('B', 'ambitieux')
PA, PB = C.phases('A'), C.phases('B')
DA, DB = C.dette_fournisseur('A'), C.dette_fournisseur('B')
CAPEX = C.capex_total()
CAPEX_M0 = sum(M.CAPEX_M0.values())
SEUIL_A, SEUIL_B = C.seuil('A'), C.seuil('B')
ro_a, ro_b = C.ro_variable_mensuel('A'), C.ro_variable_mensuel('B')
AV_A = sum(v[0] for v in C.flotte_detail('A').values())
AV_B = sum(v[0] for v in C.flotte_detail('B').values())
SOLDE_A, SOLDE_B = 10_500_000, 12_425_000
MENS_LOT_TRI = 5 * M.TYPES['tri']['prix'] * 0.70 / 18
MENS_LOT_MOTO = 5 * M.TYPES['moto']['prix'] * 0.70 / 18
MENS_A_MAX = 2 * MENS_LOT_TRI
MENS_B_MAX = MENS_A_MAX + MENS_LOT_MOTO
ASS_TRI_M = M.TYPES['tri']['assurance_an'] / 12
ASS_MOTO_M = M.TYPES['moto']['assurance_an'] / 12
SEUIL_COUV_TRI = MENS_LOT_TRI / 5 / (26 * 0.53)
SEUIL_COUV_MOTO = MENS_LOT_MOTO / 5 / (26 * 0.53)


def pic(dd):
    p = max(dd.values())
    return p, [m for m, v in dd.items() if v == p][0]


PIC_A, MPIC_A = pic(DA)
PIC_B, MPIC_B = pic(DB)


def usage_levee(cas, s):
    """Utilisation des 15 M jusqu'au point bas : investissements, avances, déficit d'exploitation net, réserve."""
    pf = C.plan_financement(cas, s['mois_mini'])
    net = pf['mens'] + pf['charges'] - pf['rec'] - pf['fonds']
    return dict(invest=pf['invest'], avances=pf['avances'], net=net, reserve=s['mini'], mois=s['mois_mini'])


UA, UB = usage_levee('A', SA), usage_levee('B', SB)
TA, TB = C.tracker_annuel('A'), C.tracker_annuel('B')
TRI_V, MOTO_V = C.tracker_par_vehicule()
STA, STB = C.sans_tracker('A'), C.sans_tracker('B')
OPTA = C.options_correctives('A')
RA = C.reprise('A')


def seuil_sans(cas):
    lo, hi = 0.4, 1.3
    for _ in range(40):
        mid = (lo + hi) / 2
        if min(l['tresorerie'] for l in M.simuler_cas(cas, mid, C.CESSION_MOTO if cas == 'B' else None, tracker=None)) >= 0: hi = mid
        else: lo = mid
    return 100 * hi


SEUIL_A_SANS, SEUIL_B_SANS = seuil_sans('A'), seuil_sans('B')
MENS_TRACKER = M.TRACKER_ANATT['tri'][0] / 12
mi0_b, mo0_b, fi0_b = C.moto_stress(0.0)


def lib_bas(u):
    return (f"réserve au point bas : {mm(u['reserve'], 1, False)}" if u['reserve'] >= 0
            else f"creux au point bas : {mm(u['reserve'], 1)} (au-delà de la levée)")


def barre(u):
    segs = [('c1', 'Investissements', u['invest']), ('c2', 'Avances sur véhicules', u['avances']),
            ('c3', 'Déficit net d’exploitation', max(u['net'], 0)), ('c4', 'Réserve', max(u['reserve'], 0))]
    tot = max(M.LEVEE, sum(v for _, _, v in segs))              # au-delà de la levée : le creux dépasse 100 %
    out = '<div class="bar4">'
    for cl, nom, v in segs:
        w = 100 * v / tot
        lib = f"{nom} {mm(v, 1, False)}" if w >= 17 else (mm(v, 1, False) if w >= 7 else '')
        out += f'<div class="{cl}" style="width:{w:.1f}%">{lib}</div>'
    return out + '</div>'


def tr(*cells, cls=''):
    return f'<tr{" class=" + chr(34) + cls + chr(34) if cls else ""}>' + ''.join(f'<td>{c}</td>' for c in cells) + '</tr>'


# =====================================================================================================
pages = []

# ------------------------------------------------------------ 8.1
pages.append(f'''<!-- ============================================================ 08 · p.1 · 8.1 -->
<section class="page" data-filigrane="TamCar">
  <div class="sec-head"><span class="num">08</span><h1>Charges d’exploitation et plan de financement</h1></div>

  <div class="hero" style="margin-top:14px">
    <span class="pill">8.1 · Objet et méthode</span>
    <div class="cols2" style="margin-top:6px">
      <p style="text-align:left">
        Cette partie montre à l’investisseur ce que TamCar devra payer pour fonctionner, comment ces
        dépenses évolueront sur 36 mois et comment les ressources initiales seront mobilisées.
      </p>
      <p style="text-align:left">
        Tous les chiffres viennent du modèle de trésorerie présenté en partie 7. Ils sont calculés
        pour deux cas de référence et pour trois scénarios d’activité.
      </p>
    </div>
  </div>

  <div class="row c-3 stretch">
    <div class="tile">
      <div class="ico">{{{{ico:wallet}}}}</div>
      <h4>Que paie TamCar ?</h4>
      <p>Des investissements de démarrage, des charges mensuelles d’exploitation, des coûts liés aux véhicules et le prix des véhicules, réglé par avances puis par mensualités.</p>
    </div>
    <div class="tile violet">
      <div class="ico">{{{{ico:chart}}}}</div>
      <h4>Comment cela évolue-t-il ?</h4>
      <p>Les charges montent avec l’ouverture de Parakou et la rémunération du développeur. Les mensualités d’achat pèsent jusqu’au mois 24, puis disparaissent.</p>
    </div>
    <div class="tile vert">
      <div class="ico">{{{{ico:target}}}}</div>
      <h4>Comment la levée est-elle mobilisée ?</h4>
      <p>Les 15 M FCFA financent le démarrage, les avances sur les véhicules et le déficit des premiers mois. Ils laissent une réserve dans le cas B et un léger creux dans le cas A, mesurés au point bas de trésorerie.</p>
    </div>
  </div>

  <div class="h-serif" style="margin-top:20px">Deux cas de référence</div>
  <table class="tbl txt" style="margin-top:10px">
    <colgroup><col style="width:14%"><col style="width:50%"><col style="width:18%"><col style="width:18%"></colgroup>
    <thead><tr><th>Cas</th><th>Flotte de TamCar</th><th>Valeur des véhicules</th><th>Levée</th></tr></thead>
    <tbody>
      {tr('<strong>Cas A</strong>', '10 tricycles neufs, livrés en deux lots de cinq : Cotonou (mois 1), Parakou (mois 7).', n(C.vehicules('A')[2]) + ' FCFA', '15 000 000 FCFA')}
      {tr('<strong>Cas B</strong>', 'Cas A + 5 motos neuves à Cotonou dès le mois 1, en test (bilan à 3 mois).', n(C.vehicules('B')[2]) + ' FCFA', '15 000 000 FCFA')}
    </tbody>
  </table>
  <div class="src">Trois scénarios d’activité : prudent (7 000 F par jour et par tricycle, 3 500 F par moto), de base (9 000 F et 4 500 F), ambitieux (12 000 F et 6 000 F).</div>

  <div class="h-serif" style="margin-top:20px">Ce que TamCar paie, et ce qu’elle ne paie pas</div>
  <div class="row c-1-1 stretch">
    <div class="card">
      <div class="eyebrow">{{{{ico:coins}}}} À la charge de TamCar</div>
      <ul class="liste" style="margin-top:0">
        <li>les investissements de démarrage (8.2) ;</li>
        <li>les charges mensuelles : équipe, locaux, prestataires, promotions (8.3) ;</li>
        <li>l’impôt minimum sur les sociétés et la patente (8.3) ;</li>
        <li>l’assurance, le droit taxi, la visite technique et le tracker GPS des véhicules, tant qu’elle en est propriétaire (8.3 et 8.4) ;</li>
        <li>le prix des véhicules : avances puis mensualités (8.6).</li>
      </ul>
    </div>
    <div class="card">
      <div class="eyebrow rouille">{{{{ico:shield}}}} Pas à la charge de TamCar</div>
      <ul class="liste rouille" style="margin-top:0">
        <li>le carburant, l’entretien et les réparations : au conducteur ;</li>
        <li>les frais de paiement Mobile Money : au client ;</li>
        <li>les charges sociales de l’employeur : les rémunérations sont indiquées en brut.</li>
      </ul>
    </div>
  </div>

  <div class="pn"><b><!--PN--></b> sur <!--TOTAL--></div>
</section>
''')

# ------------------------------------------------------------ 8.2
pages.append(f'''<!-- ============================================================ 08 · p.2 · 8.2 -->
<section class="page" data-filigrane="TamCar">
  <div class="sec-head"><span class="num">08</span><h1>Charges d’exploitation et plan de financement <small>(suite)</small></h1></div>

  <div class="h-serif" style="margin-top:14px">8.2 · Les investissements de démarrage</div>
  <p class="intro">Ces dépenses sont payées une seule fois. Elles sont identiques dans les cas A et B.</p>

  <table class="tbl txt" style="margin-top:10px">
    <colgroup><col style="width:44%"><col style="width:16%"><col style="width:12%"><col style="width:28%"></colgroup>
    <thead><tr><th>Poste</th><th style="text-align:right">Montant (FCFA)</th><th>Quand</th><th>Nature</th></tr></thead>
    <tbody>
      {tr('Formalisation de la société', '<div style="text-align:right">1 500 000</div>', 'Mois 0', 'Statuts, RCCM, IFU, annonce, évaluation de l’apport en nature (forfait retenu avec un expert-comptable, commissaire aux apports)')}
      {tr('ANATT : autorisation d’exploitation et attestations', '<div style="text-align:right">300 000</div>', 'Mois 0', 'Obligation réglementaire ; renouvelée chaque année (8.3)')}
      {tr('Juriste : contrats', '<div style="text-align:right">100 000</div>', 'Mois 0', 'Contrats chauffeurs, cession, partenaires')}
      {tr('Bureau de Cotonou : caution et aménagement', '<div style="text-align:right">500 000</div>', 'Mois 0', 'Accueil, dossiers, chauffeurs')}
      {tr('Bureau de Parakou : caution et aménagement', '<div style="text-align:right">500 000</div>', 'Mois 6', 'Payé avec le second lot')}
      {tr('Matériel informatique et mobilier des deux bureaux', '<div style="text-align:right">1 000 000</div>', 'Mois 0', 'Postes, imprimante, mobilier')}
      {tr('Marketing de lancement : photo, vidéo, sponsoring', '<div style="text-align:right">1 000 000</div>', 'Mois 0', 'Seul marketing budgété en investissement')}
      {tr('Graphisme', '<div style="text-align:right">150 000</div>', 'Mois 0', 'Supports de communication')}
      {tr('<strong>Total</strong>', '<div style="text-align:right"><strong>' + n(CAPEX) + '</strong></div>', '', f'{n(CAPEX_M0)} au mois 0 ; 500 000 au mois 6')}
    </tbody>
  </table>

  <div class="row c-1-1 stretch" style="margin-top:12px">
    <div class="callout">
      <strong>Apport en nature.</strong> La plateforme (4 000 000 FCFA de dépenses documentées) est
      apportée en nature à la société. Ce n’est pas un décaissement : elle n’apparaît pas dans ces
      investissements.
    </div>
    <div class="callout rouille">
      <strong>Pas de marketing récurrent.</strong> Le plan ne budgète ni publicité payante, ni marketing
      de rue, ni radio, ni parrainage. Seuls le lancement et la promotion de première course sont
      financés.
    </div>
  </div>

  <div class="h-serif" style="margin-top:22px">Ce que ces dépenses représentent dans la levée</div>
  <div class="row c-3" style="margin-top:10px">
    <div class="kpi"><b>{mm(CAPEX, 2, False)}</b><span>investissements de démarrage</span><small>{pct(100 * CAPEX / M.LEVEE, 0)} des 15 M FCFA</small></div>
    <div class="kpi"><b>{mm(CAPEX_M0, 2, False)}</b><span>payés au mois 0</span><small>avant le premier revenu</small></div>
    <div class="kpi"><b>0,50 M</b><span>payés au mois 6</span><small>bureau de Parakou</small></div>
  </div>

  <div class="pn"><b><!--PN--></b> sur <!--TOTAL--></div>
</section>
''')

# ------------------------------------------------------------ 8.3
pages.append(f'''<!-- ============================================================ 08 · p.3 · 8.3 -->
<section class="page" data-filigrane="TamCar">
  <div class="sec-head"><span class="num">08</span><h1>Charges d’exploitation et plan de financement <small>(suite)</small></h1></div>

  <div class="h-serif" style="margin-top:14px">8.3 · Les charges d’exploitation mensuelles</div>
  <p class="intro">Montants mensuels en FCFA. « Variable » signifie qu’ils suivent le volume de courses. Les rémunérations sont indiquées en brut.</p>

  <table class="tbl txt" style="margin-top:10px">
    <colgroup><col style="width:32%"><col style="width:22%"><col style="width:12%"><col style="width:34%"></colgroup>
    <thead><tr><th>Poste</th><th>Montant</th><th>Nature</th><th>Début et remarque</th></tr></thead>
    <tbody>
      {tr('<strong>Équipe</strong>', '', '', '')}
      {tr('Responsables Opérations', '3 % du volume de la ville, plafonné à 150 000', 'Variable', f'Cotonou dès le mois 1, Parakou dès le mois 7. Base : {n(ro_a[0])} chacun (cas A) ; Cotonou {n(ro_b[0])} (cas B)')}
      {tr('Secrétaire-comptable', '100 000', 'Fixe', 'Dès le mois 1')}
      {tr('Développeur', '200 000', 'Fixe', 'Dès le mois 13 ; le fondateur assure la maintenance la première année')}
      {tr('Infrastructure technique', '75 000', 'Fixe', 'Dès le mois 1 : backend, base de données, hébergement, cartographie, notifications')}
      {tr('Outil de développement (Claude Code)', '75 000', 'Fixe', 'Mois 1 à 12 ; ensuite couvert par la rémunération du développeur')}
      {tr('<strong>Locaux</strong>', '', '', '')}
      {tr('Bureaux, électricité et eau', '50 000 par bureau, 100 000 d’électricité et d’eau', 'Fixe', 'Bureau de Cotonou dès le mois 1, de Parakou dès le mois 7')}
      {tr('<strong>Prestataires et promotions</strong>', '', '', '')}
      {tr('Comptable externe et juriste consultant', '75 000 et 50 000 par trimestre', 'Fixe', 'Un versement par trimestre')}
      {tr('Assurance multirisque professionnelle', '50 000', 'Fixe', 'Dès le mois 1')}
      {tr('Promotions de lancement', 'Budget plafonné', 'Fixe', 'Six premiers mois ; budget arrêté avant le lancement (4.5.3)')}
      {tr('Autorisation de transporteur ANATT', '280 000 par an', 'Fixe', 'Renouvellement annuel, aux mois 13 et 25 (la première est dans l’investissement de démarrage)')}
      {tr('Impôts et taxes', f'Impôt minimum de {n(M.IS_MINIMUM)} par an ; patente de {n(M.PATENTE["Cotonou"])} (Cotonou) et {n(M.PATENTE["Parakou"])} (Parakou)', 'Fixe', 'Impôt aux mois 16 et 28 ; patente dès la 2e année (mois 13 et 25, mois 19 et 31). Aucune exonération')}
      {tr('<strong>Véhicules détenus par TamCar</strong>', '', '', '')}
      {tr('Assurance, droit taxi, visite technique', f'75 000 par an et par tricycle ({n(ASS_TRI_M)} par mois)<br>50 000 par an et par moto ({n(ASS_MOTO_M)} par mois)', 'Fixe', 'Depuis la livraison, jusqu’à la cession du véhicule au chauffeur')}
      {tr('Tracker GPS certifié ANATT', '139 000 en année 1, puis 89 000 par an (tricycle) ou 49 000 par an (moto)', 'Fixe', 'Payé à la livraison puis à chaque anniversaire, jusqu’à la cession (8.4)')}
    </tbody>
  </table>

  <div class="callout" style="margin-top:12px">
    <strong>Carburant, entretien et réparations : à la charge du conducteur.</strong> Les véhicules
    sont neufs et vendus avec la garantie du fournisseur : TamCar ne prend en charge que les défauts couverts par cette garantie.
    Aucune provision d’entretien ni de réparation n’est inscrite dans ses charges.
  </div>


  <div class="pn"><b><!--PN--></b> sur <!--TOTAL--></div>
</section>
''')


# ------------------------------------------------------------ 8.4
pages.append(f'''<!-- ============================================================ 08 · p.4 · 8.4 -->
<section class="page" data-filigrane="TamCar">
  <div class="sec-head"><span class="num">08</span><h1>Charges d’exploitation et plan de financement <small>(suite)</small></h1></div>

  <div class="h-serif" style="margin-top:14px">8.4 · Les trackers GPS : une obligation et un outil de contrôle</div>

  <div class="hero" style="margin-top:12px; padding:18px 24px">
    <span class="pill">Tracker GPS certifié ANATT</span>
    <div class="cols2" style="margin-top:4px">
      <p style="text-align:left">
        Le tracker est un boîtier GPS posé dans le véhicule. Il transmet sa position en continu,
        indépendamment du téléphone du conducteur. Selon le relevé de l’ANATT, un dispositif certifié est
        obligatoire pour les véhicules de transport ; il se renouvelle chaque année.
      </p>
      <p style="text-align:left">
        Pour TamCar, il a deux fonctions : c’est une condition pour exploiter légalement, et c’est
        l’outil qui protège et contrôle les véhicules qu’elle possède.
      </p>
    </div>
  </div>

  <div class="row c-1-1 stretch" style="margin-top:12px">
    <table class="tbl" style="margin-top:0">
      <colgroup><col style="width:28%"><col style="width:24%"><col style="width:24%"><col style="width:24%"></colgroup>
      <thead><tr><th>Par véhicule, en FCFA</th><th>Année 1</th><th>Années suivantes</th><th>Sur la détention par TamCar</th></tr></thead>
      <tbody>
        {tr('Tricycle', '139 000', '89 000', f'<strong>{n(TRI_V)}</strong><small>36 mois</small>')}
        {tr('Moto', '139 000', '49 000', f'<strong>{n(MOTO_V)}</strong><small>24 mois</small>')}
      </tbody>
    </table>
    <table class="tbl" style="margin-top:0">
      <colgroup><col style="width:28%"><col style="width:18%"><col style="width:18%"><col style="width:18%"><col style="width:18%"></colgroup>
      <thead><tr><th>Dans le plan, en FCFA</th><th>Année 1</th><th>Année 2</th><th>Année 3</th><th>Total</th></tr></thead>
      <tbody>
        {tr('Cas A', n(TA[0]), n(TA[1]), n(TA[2]), f'<strong>{n(sum(TA))}</strong>')}
        {tr('Cas B', n(TB[0]), n(TB[1]), n(TB[2]), f'<strong>{n(sum(TB))}</strong>')}
      </tbody>
    </table>
  </div>
  <div class="src">Prix de l’ANATT relevés en juillet 2026 et maintenus. Paiement annuel, à la livraison puis à chaque anniversaire, tant que TamCar est propriétaire ; à la cession, le chauffeur reprend le renouvellement.</div>

  <div class="rule-label" style="margin-top:14px">Pourquoi le tracker compte pour le business</div>
  <div class="row c-3 stretch" style="margin-top:8px">
    <div class="tile">
      <div class="ico">{{{{ico:shield}}}}</div>
      <h4>Conformité</h4>
      <p>Sans dispositif certifié, le véhicule ne peut pas être autorisé au transport. C’est une condition d’exploitation, pas une option.</p>
    </div>
    <div class="tile violet">
      <div class="ico">{{{{ico:car}}}}</div>
      <h4>Protection de l’actif</h4>
      <p>TamCar possède de {n(C.vehicules('A')[2])} à {n(C.vehicules('B')[2])} FCFA de véhicules. Le tracker permet de les localiser et de les récupérer en cas de vol ou de détournement.</p>
    </div>
    <div class="tile vert">
      <div class="ico">{{{{ico:coins}}}}</div>
      <h4>Intégrité des revenus</h4>
      <p>La commission dépend des courses enregistrées. La position du véhicule permet de repérer une activité hors plateforme et de rapprocher kilomètres et courses.</p>
    </div>
  </div>
  <div class="row c-3 stretch">
    <div class="tile or">
      <div class="ico">{{{{ico:alert}}}}</div>
      <h4>Sécurité et litiges</h4>
      <p>En cas d’accident, d’incident ou de réclamation, l’historique de position sert de preuve. Il complète le suivi en direct de la plateforme, qui repose sur le téléphone du conducteur.</p>
    </div>
    <div class="tile">
      <div class="ico">{{{{ico:chart}}}}</div>
      <h4>Pilotage de la flotte</h4>
      <p>Disponibilité, immobilisations, kilomètres parcourus : ces données alimentent les indicateurs de rentabilité (6.6) et le calendrier d’entretien.</p>
    </div>
    <div class="tile violet">
      <div class="ico">{{{{ico:clipboard}}}}</div>
      <h4>Cession et assurance</h4>
      <p>L’historique d’usage documente l’état du véhicule à la cession et peut peser dans les conditions d’assurance.</p>
    </div>
  </div>

  <div class="row c-1-1 stretch" style="margin-top:12px">
    <div class="callout">
      <strong>Qui paie.</strong> TamCar, pour les véhicules qu’elle possède, jusqu’à leur cession. Pour les véhicules des
      concessionnaires partenaires, le tracker reste à leur charge. Le demander au conducteur pèserait
      {n(MENS_TRACKER)} F par mois sur son revenu en main : 12 % pour un tricycle, 25 % pour une moto.
    </div>
    <div class="callout rouille">
      <strong>Effet sur le plan.</strong> Les trackers coûtent {n(sum(TA))} FCFA (cas A) et {n(sum(TB))} FCFA (cas B) sur
      36 mois. Point bas du cas A : {mm(STA['mini'])} sans tracker, {mm(SA['mini'])} avec ; cas B : {mm(STB['mini'])}
      contre {mm(SB['mini'])}. Marge de sécurité : {pct(SEUIL_A_SANS, 0)} contre {pct(SEUIL_A, 0)} de l’objectif
      (cas A), {pct(SEUIL_B_SANS, 0)} contre {pct(SEUIL_B, 0)} (cas B).
    </div>
  </div>
  <div class="rnote">Confirmé : TamCar paie les trackers de ses véhicules, le concessionnaire ceux des siens. Hypothèse de ma part : paiement annuel d’avance. À confirmer avec l’ANATT : obligation pour tricycles et motos, étalement possible. Le suivi live actuel repose sur le GPS du téléphone du conducteur ; l’intégration des trackers dans l’espace de gestion reste à développer.</div>

  <div class="pn"><b><!--PN--></b> sur <!--TOTAL--></div>
</section>
''')

# ------------------------------------------------------------ 8.4
def table_phases(P, titre):
    lignes = ''
    for p in P:
        autres = p['locaux'] + p['presta']
        lignes += tr(f"<strong>{p['nom']}</strong><small>{p['sous']}</small>", n(p['rec']), n(p['charges']), n(p['equipe']), n(autres), n(p['assur'] + p['tracker'] + p['anatt'] + p['impots']),
                     n(p['mens']), f'<strong>{sg(p["flux"])}</strong>')
    return f'''<table class="tbl" style="margin-top:8px">
    <colgroup><col style="width:24%"><col style="width:12%"><col style="width:13%"><col style="width:11%"><col style="width:11%"><col style="width:11%"><col style="width:9%"><col style="width:9%"></colgroup>
    <thead><tr><th>{titre}</th><th>Revenus</th><th>Charges</th><th>dont équipe</th><th>dont locaux, prestataires</th><th>dont assurances, trackers, ANATT, impôts</th><th>Mensualités d’achat</th><th>Flux</th></tr></thead>
    <tbody>{lignes}</tbody>
  </table>'''


ecart_charges_a = PA[3]['charges'] - PA[0]['charges']
pages.append(f'''<!-- ============================================================ 08 · p.5 · 8.5 -->
<section class="page" data-filigrane="TamCar">
  <div class="sec-head"><span class="num">08</span><h1>Charges d’exploitation et plan de financement <small>(suite)</small></h1></div>

  <div class="h-serif" style="margin-top:14px">8.5 · L’évolution des charges dans le temps</div>
  <p class="intro">Moyennes mensuelles par phase, scénario de base, en FCFA. Le flux est ce qui reste après les charges, les mensualités d’achat et les revenus ; les avances sur véhicules et les investissements sont comptés à part.</p>

  {table_phases(PA, 'Cas A · 10 tricycles')}
  {table_phases(PB, 'Cas B · A + 5 motos')}
  <div class="src">Le flux du mois 25 à 36 inclut, dans le cas B, l’encaissement du fonds de rachat des motos cédées.</div>

  <div class="row c-1-1 stretch" style="margin-top:12px">
    <div class="callout">
      <strong>Ce qui fait monter les charges.</strong> Entre les mois 1 à 6 et les mois 25 à 36, les
      charges du cas A passent de {n(PA[0]['charges'])} à {n(PA[3]['charges'])} FCFA par mois
      ({sg(ecart_charges_a)}) : le bureau et le responsable de Parakou, la rémunération du développeur,
      l’assurance et les trackers des tricycles du second lot.
    </div>
    <div class="callout vert">
      <strong>Ce qui les compense.</strong> Les revenus doublent avec le second lot, de
      {n(PA[0]['rec'])} à {n(PA[1]['rec'])} FCFA par mois. Le flux mensuel du cas A devient positif
      de façon stable à partir du mois {SA['stable']}.
    </div>
  </div>

  <div class="pn"><b><!--PN--></b> sur <!--TOTAL--></div>
</section>
''')

# ------------------------------------------------------------ 8.5
pages.append(f'''<!-- ============================================================ 08 · p.6 · 8.6 -->
<section class="page" data-filigrane="TamCar">
  <div class="sec-head"><span class="num">08</span><h1>Charges d’exploitation et plan de financement <small>(suite)</small></h1></div>

  <div class="h-serif" style="margin-top:14px">8.6 · Le financement des véhicules</div>
  <p class="intro">Le fournisseur accorde à TamCar un paiement de <strong>30 % à la commande</strong> de chaque lot et le <strong>solde sur 18 mois</strong>, sans intérêts.</p>

  <table class="tbl" style="margin-top:10px">
    <colgroup><col style="width:26%"><col style="width:13%"><col style="width:16%"><col style="width:15%"><col style="width:15%"><col style="width:15%"></colgroup>
    <thead><tr><th>Lot</th><th>Valeur</th><th>Avance à la commande</th><th>Mensualité</th><th>Mensualités</th><th>Dernier paiement</th></tr></thead>
    <tbody>
      {tr('Lot 1 · 5 tricycles · Cotonou', n(7_500_000), '2 250 000 (mois 0)', n(MENS_LOT_TRI), 'Mois 1 à 18', 'Mois 18')}
      {tr('Lot 2 · 5 tricycles · Parakou', n(7_500_000), '2 250 000 (mois 6)', n(MENS_LOT_TRI), 'Mois 7 à 24', 'Mois 24')}
      {tr('<strong>Cas A · total</strong>', '<strong>' + n(15_000_000) + '</strong>', f'<strong>{n(AV_A)}</strong>', f'<strong>{n(MENS_A_MAX)}</strong> au plus', '', '')}
      {tr('Cas B · 5 motos · Cotonou', n(2_750_000), '825 000 (mois 0)', n(MENS_LOT_MOTO), 'Mois 1 à 18', 'Mois 18')}
      {tr('<strong>Cas B · total</strong>', '<strong>' + n(17_750_000) + '</strong>', f'<strong>{n(AV_B)}</strong>', f'<strong>{n(MENS_B_MAX)}</strong> au plus', '', '')}
    </tbody>
  </table>
  <div class="src">Mensualité maximale : mois 7 à 18, lorsque les deux lots de tricycles (et, dans le cas B, les motos) sont en remboursement.</div>

  <div class="h-serif" style="margin-top:20px">Ce que TamCar doit encore au fournisseur</div>
  <table class="tbl" style="margin-top:10px">
    <colgroup><col style="width:34%"><col style="width:16.5%"><col style="width:16.5%"><col style="width:16.5%"><col style="width:16.5%"></colgroup>
    <thead><tr><th>Solde dû, en FCFA</th><th>Mois 6</th><th>Mois 12</th><th>Mois 18</th><th>Mois 24</th></tr></thead>
    <tbody>
      {tr('Cas A', n(DA[6]), n(DA[12]), n(DA[18]), n(DA[24]))}
      {tr('Cas B', n(DB[6]), n(DB[12]), n(DB[18]), n(DB[24]))}
    </tbody>
  </table>
  <div class="src">Le solde dû est à son maximum au mois {MPIC_A} dans le cas A ({n(PIC_A)} FCFA) et au mois {MPIC_B} dans le cas B ({n(PIC_B)} FCFA), lorsque le second lot est commandé.</div>

  <div class="row c-1-1 stretch" style="margin-top:12px">
    <div class="callout">
      <strong>Qui rembourse ?</strong> Les véhicules eux-mêmes. À l’objectif, la part propriétaire (30 %
      du volume) d’un tricycle est de 70 200 FCFA par mois, pour une mensualité de
      {n(MENS_LOT_TRI / 5)}. La mensualité est couverte dès {n(SEUIL_COUV_TRI)} F de courses par jour
      ({pct(100 * SEUIL_COUV_TRI / 9000, 0)} de l’objectif). Pour une moto : {n(SEUIL_COUV_MOTO)} F par
      jour ({pct(100 * SEUIL_COUV_MOTO / 4500, 0)} de l’objectif).
    </div>
    <div class="callout rouille">
      <strong>Durée de cession.</strong> Le tricycle est cédé au chauffeur après 36 mois, la moto après
      24 mois (hypothèse retenue). À la cession, TamCar ne garde que ses 20 % de plateforme, cesse de
      payer l’assurance et encaisse le fonds de rachat du chauffeur, qui correspond à la valeur résiduelle.
    </div>
  </div>

  <div class="callout ajout" style="margin-top:10px">
    <strong>Non comptées.</strong> Les avances des concessionnaires partenaires (50 000 F par moto, 75 000 F
    par tricycle, 100 000 F par voiture) sont remboursables : elles ne figurent pas dans la trésorerie et
    constitueraient un complément de liquidités, en dette.
  </div>

  <div class="pn"><b><!--PN--></b> sur <!--TOTAL--></div>
</section>
''')

# ------------------------------------------------------------ 8.6
def table_emplois(cas):
    cols = [C.plan_financement(cas, mo) for mo in (0, 12, 24, 36)]
    def ligne(nom, cle, fort=False):
        cells = [n(c[cle]) if c[cle] else '—' for c in cols]
        if fort:
            return tr(f'<strong>{nom}</strong>', *[f'<strong>{x}</strong>' for x in cells])
        return tr(nom, *cells)
    solde = tr('<strong>Solde de trésorerie</strong>', *[f'<strong>{sg(c["solde"])}</strong>' for c in cols])
    return f'''<table class="tbl" style="margin-top:8px">
    <colgroup><col style="width:40%"><col style="width:15%"><col style="width:15%"><col style="width:15%"><col style="width:15%"></colgroup>
    <thead><tr><th>Cas {cas}, cumul en FCFA</th><th>Mois 0</th><th>Mois 12</th><th>Mois 24</th><th>Mois 36</th></tr></thead>
    <tbody>
      {ligne('Investissements de démarrage', 'invest')}
      {ligne('Avances sur véhicules', 'avances')}
      {ligne('Mensualités d’achat payées', 'mens')}
      {ligne('Charges d’exploitation', 'charges')}
      {ligne('Total des emplois', 'emplois', True)}
      {ligne('Levée de fonds', 'levee')}
      {ligne('Revenus de TamCar (courses)', 'rec')}
      {ligne('Fonds de rachat encaissés (motos cédées)', 'fonds')}
      {ligne('Total des ressources', 'ressources', True)}
      {solde}
    </tbody>
  </table>'''


pages.append(f'''<!-- ============================================================ 08 · p.7 · 8.7 -->
<section class="page" data-filigrane="TamCar">
  <div class="sec-head"><span class="num">08</span><h1>Charges d’exploitation et plan de financement <small>(suite)</small></h1></div>

  <div class="h-serif" style="margin-top:14px">8.7 · Le plan de financement</div>
  <p class="intro">Emplois et ressources cumulés, scénario de base. Le solde de trésorerie est celui de la projection de la partie 7.</p>

  {table_emplois('A')}
  {table_emplois('B')}

  <div class="h-serif" style="margin-top:18px">Comment les 15 M FCFA sont mobilisés</div>
  <p class="intro">Utilisation de la levée jusqu’au point bas de trésorerie : cas A au mois {UA['mois']}, cas B au mois {UB['mois']}.</p>
  <div class="bar-label">Cas A <small>{lib_bas(UA)}</small></div>
  {barre(UA)}
  <div class="bar-label">Cas B <small>{lib_bas(UB)}</small></div>
  {barre(UB)}
  <div class="src">Turquoise : investissements de démarrage · orange : avances sur véhicules · violet : déficit net d’exploitation (charges et mensualités moins revenus) · bleu : réserve restante.</div>

  <div class="pn"><b><!--PN--></b> sur <!--TOTAL--></div>
</section>
''')

# ------------------------------------------------------------ 8.7
def ligne_sc(cas, sc, s, nom):
    besoin = M.LEVEE - min(0, s['mini'])
    return tr(f'Cas {cas} · {nom}', sg(s['mini']) + f' (mois {s["mois_mini"]})', sg(s['fin']), str(s['mois_neg']),
              n(besoin) if s['mini'] < 0 else '15 000 000 (suffisante)')


mi100, mo100, fi100 = C.moto_stress(1.0)
mi50, mo50, fi50 = C.moto_stress(0.5)
mi34, mo34, fi34 = C.moto_stress(0.34)
mi0, mo0, fi0 = C.moto_stress(0.0)
pages.append(f'''<!-- ============================================================ 08 · p.8 · 8.8 -->
<section class="page" data-filigrane="TamCar">
  <div class="sec-head"><span class="num">08</span><h1>Charges d’exploitation et plan de financement <small>(suite)</small></h1></div>

  <div class="h-serif" style="margin-top:14px">8.8 · Sensibilité et seuils de pilotage</div>

  <table class="tbl" style="margin-top:10px">
    <colgroup><col style="width:22%"><col style="width:22%"><col style="width:16%"><col style="width:16%"><col style="width:24%"></colgroup>
    <thead><tr><th>Cas et scénario</th><th>Point bas de trésorerie</th><th>Trésorerie au mois 36</th><th>Mois à flux négatif</th><th>Levée qui couvre le scénario</th></tr></thead>
    <tbody>
      {ligne_sc('A', 'prudent', SAP, 'prudent')}
      {ligne_sc('A', 'base', SA, 'de base')}
      {ligne_sc('A', 'ambitieux', SAA, 'ambitieux')}
      {ligne_sc('B', 'prudent', SBP, 'prudent')}
      {ligne_sc('B', 'base', SB, 'de base')}
      {ligne_sc('B', 'ambitieux', SBA, 'ambitieux')}
    </tbody>
  </table>

  <div class="row c-1-1 stretch" style="margin-top:12px">
    <div class="callout vert">
      <strong>Marge de sécurité.</strong> Pour une trésorerie positive chaque mois, le cas A demande {pct(SEUIL_A, 0)} de
      l’objectif et le cas B {pct(SEUIL_B, 0)}. En dessous, la trésorerie devient négative.
    </div>
    <div class="callout rouille">
      <strong>Scénario prudent.</strong> Aucun des deux cas ne tient : {mm(SAP['mini'])} au point bas pour le
      cas A, {mm(SBP['mini'])} pour le cas B. Les motos réduisent le besoin de financement de
      {mm(SBP['mini'] - SAP['mini'], 1, False)}.
    </div>
  </div>

  <div class="h-serif ajout" style="margin-top:20px">Le test moto : bilan à 3 mois, sans arrêt automatique</div>
  <p class="intro ajout-in">Les cinq motos restent en service. À 3 mois, on mesure le volume par moto (objectif : 4 500 F par jour), le nombre de chauffeurs qui restent et le revenu réel du chauffeur, puis on décide de l’extension.</p>
  <table class="tbl ajout" style="margin-top:10px">
    <colgroup><col style="width:34%"><col style="width:22%"><col style="width:22%"><col style="width:22%"></colgroup>
    <thead><tr><th>Volume des motos, tricycles à 100 %</th><th>Point bas de trésorerie</th><th>Mois 36</th><th>Décision au bilan</th></tr></thead>
    <tbody>
      {tr('100 % de l’objectif (4 500 F par jour)', sg(mi100), sg(fi100), 'Étendre : lot de motos à Parakou')}
      {tr('50 % (2 250 F par jour)', sg(mi50), sg(fi50), 'Poursuivre sans étendre')}
      {tr('34 % (1 552 F par jour)', sg(mi34), sg(fi34), 'Plan correctif, puis nouveau bilan à 3 mois')}
      {tr('0 % (motos vides)', sg(mi0), sg(fi0), 'Pire cas : le plan finit à ' + mm(fi0))}
    </tbody>
  </table>
  <div class="src ajout-in">Une moto rembourse sa mensualité dès 1 552 F de courses par jour (34 % de l’objectif). En dessous, TamCar complète sur sa trésorerie.</div>

  <div class="pn"><b><!--PN--></b> sur <!--TOTAL--></div>
</section>
''')

# ------------------------------------------------------------ 8.8
pages.append(f'''<!-- ============================================================ 08 · p.9 · 8.9 -->
<section class="page" data-filigrane="TamCar">
  <div class="sec-head"><span class="num">08</span><h1>Charges d’exploitation et plan de financement <small>(suite)</small></h1></div>

  <div class="h-serif" style="margin-top:14px">8.9 · Conclusion et conditions retenues</div>

  <div class="hero" style="margin-top:12px; padding:22px 26px">
    <span class="pill">Conclusion</span>
    <div class="cols2" style="margin-top:8px">
      <p style="text-align:left">
        TamCar fonctionne avec une structure légère : environ {n(PA[3]['charges'])} FCFA de charges
        mensuelles à régime établi, dont environ la moitié pour l’équipe. Le prix des véhicules est
        payé par les véhicules eux-mêmes, avec 30 % à la commande et le solde sur 18 mois.
      </p>
      <p style="text-align:left">
        Avec 15 M FCFA de levée, le scénario de base laisse, dans le cas B, une réserve de
        {mm(SB['mini'], 1, False)} au point bas et aucun mois de trésorerie négative. Dans le cas A, le point
        bas est de {mm(SA['mini'])} au mois {SA['mois_mini']} : {SA['tres_neg']} mois de trésorerie négative, laissés tels quels dans
        le plan, puis la trésorerie remonte à {mm(SA['fin'], 1, False)} au mois 36. Le scénario prudent n’est couvert
        dans aucun des deux cas.
      </p>
      <p style="text-align:left">
        Le seuil de pilotage est net : avec les trackers, le volume par véhicule doit atteindre
        {pct(SEUIL_A, 0)} de l’objectif dans le cas A et {pct(SEUIL_B, 0)} dans le cas B. Le bilan du test
        moto à 3 mois décide de l’extension.
      </p>
    </div>
  </div>

  <div class="h-serif" style="margin-top:22px">Conditions retenues</div>
  <div class="row c-1-1 stretch">
    <div class="card">
      <div class="eyebrow">{{{{ico:clipboard}}}} Achat et conformité</div>
      <ul class="liste" style="margin-top:0">
        <li>paiement de 30 % à la commande et solde sur 18 mois, sans intérêts, confirmés avec le fournisseur ;</li>
        <li>prix de 1 500 000 F par tricycle et de 550 000 F par moto, calendrier de livraison et prix maintenus ;</li>
        <li>véhicules achetés neufs et vendus avec la garantie du fournisseur : entretien et réparations à la charge du conducteur ;</li>
        <li>ANATT : autorisation de 300 000 F au démarrage, puis 280 000 F à chaque renouvellement annuel ; trackers certifiés payés chaque année d’avance.</li>
      </ul>
    </div>
    <div class="card">
      <div class="eyebrow violet">{{{{ico:shield}}}} Cession et fiscalité</div>
      <ul class="liste" style="margin-top:0">
        <li>cession en 24 mois pour la moto et 36 mois pour le tricycle ; le fonds de rachat est le prix de la valeur résiduelle du véhicule ;</li>
        <li>impôt minimum sur les sociétés ({n(M.IS_MINIMUM)} F par an) et patente chiffrés en 8.3, sans aucune exonération : {n(SA['cats']['c_impots'])} F sur 36 mois dans le cas A ;</li>
        <li>coût de la promotion de première course : inclus dans les charges, montant non détaillé ici.</li>
      </ul>
    </div>
  </div>

  <div class="callout ajout" style="margin-top:14px">
    <strong>Après le creux du cas A.</strong> Le point bas ({mm(SA['mini'])}, mois {SA['mois_mini']}) représente
    {pct(100 * abs(SA['mini']) / M.LEVEE, 1)} de la levée ; la trésorerie est négative ({RA['txt']}). Elle redevient positive de façon
    durable au mois {RA['premier']} ({mm(RA['t_premier'])}), puis {mm(RA['t30'])} au mois 30 et {mm(RA['t36'])} au mois 36, soit environ
    {mm(RA['moyen'], 2, False)} par mois à régime établi. Le plan laisse ce creux tel quel ; des véhicules de concessionnaires
    le feraient disparaître (10.9).
  </div>

  <div class="pn"><b><!--PN--></b> sur <!--TOTAL--></div>
</section>
''')

(ICI / 'partie8.html').write_text('\n'.join(pages), encoding='utf-8')
print('partie8.html :', len(pages), 'pages')
